KRIPTOTAHLIL ASOSLARI — DASTUR KODLARI
=======================================

Ushbu papkada o'quv qo'llanmada keltirilgan barcha dasturlar joylashgan.
Dasturlar grafiklarni Times New Roman (Liberation Serif) shriftida,
300 DPI sifatda, rangli chizadi.

Ishga tushirish:
  pip install numpy matplotlib sympy scipy scikit-learn cryptography pillow
  cd dasturlar
  python3 bob03_klassik.py      (masalan)

Fayllar:
  dasturlar/umumiy.py        - yordamchi modul (rasm, jadval saqlash, shrift sozlamalari)
  dasturlar/shifrlar.py      - o'quv shifrlari va S-bloklar
  dasturlar/korpus.txt       - o'zbek tili korpusi
  dasturlar/bobNN_*.py       - har bir bob dasturi (01-11)
  natijalar/bobNN/           - dasturlar hosil qilgan rangli rasm va jadvallar (300 DPI)

Barcha kodlar faqat o'quv maqsadiga mo'ljallangan.
