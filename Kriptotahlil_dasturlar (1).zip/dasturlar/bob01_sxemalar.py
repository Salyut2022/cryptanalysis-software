# -*- coding: utf-8 -*-
"""1-bob: kriptologiya tuzilmasi va shifrlangan aloqa modeli sxemalari."""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from umumiy import rasm_saqla


def quti(ax, x, y, w, h, matn, rang="#dbe8f5", shrift=9, qalin=False):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.02",
                                fc=rang, ec="#1f3b5c", lw=1.2))
    ax.text(x, y, matn, ha="center", va="center", fontsize=shrift,
            fontweight="bold" if qalin else "normal")


def strelka(ax, x1, y1, x2, y2, matn=None, dy=0.0):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color="#1f3b5c", lw=1.2))
    if matn:
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + dy, matn, ha="center", va="bottom", fontsize=8)


# 1-rasm: kriptologiyaning tuzilmasi
fig, ax = plt.subplots(figsize=(9, 4.4))
ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.axis("off")
quti(ax, 5, 5.3, 2.6, 0.7, "KRIPTOLOGIYA", "#b7d0ea", 11, True)
quti(ax, 2.5, 3.9, 3.4, 0.7, "Kriptografiya\n(himoya usullarini yaratish)", "#cfe3c8", 9, True)
quti(ax, 7.5, 3.9, 3.4, 0.7, "Kriptotahlil\n(himoya bardoshliligini baholash)", "#f6d7c3", 9, True)
strelka(ax, 4.4, 4.95, 2.9, 4.27); strelka(ax, 5.6, 4.95, 7.1, 4.27)
chap = ["Simmetrik shifrlar (blokli, oqimli)", "Asimmetrik kriptotizimlar", "Xesh-funksiyalar, ERI, MAC", "Kriptografik protokollar"]
ong = ["Klassik shifrlar tahlili", "Universal va statistik usullar", "Maxsus usullar (chiziqli, differensial ...)", "Amalga oshirish hujumlari (yon kanal)"]
for ustun, x0, rang in ((chap, 2.5, "#eaf4e6"), (ong, 7.5, "#fcebe0")):
    xl = x0 - 1.85
    ax.plot([xl, xl], [3.52, 0.55], color="#1f3b5c", lw=1.2)
    for i, t in enumerate(ustun):
        y = 2.95 - i * 0.8
        quti(ax, x0 + 0.15, y, 3.3, 0.6, t, rang, 8)
        strelka(ax, xl, y, x0 - 1.5, y)
ax.annotate("", xy=(5.85, 3.9), xytext=(4.15, 3.9), arrowprops=dict(arrowstyle="<|-|>", color="gray", lw=1, ls="--"))
ax.text(5, 3.62, "o‘zaro\nrivojlantiradi", ha="center", fontsize=8, color="gray")
rasm_saqla(fig, "bob01", "kriptologiya_tuzilmasi")

# 2-rasm: shifrlangan aloqa modeli (Alisa, Bob, Tridi)
fig, ax = plt.subplots(figsize=(9, 3.4))
ax.set_xlim(0, 10); ax.set_ylim(0, 4); ax.axis("off")
quti(ax, 0.9, 2.8, 1.5, 0.7, "Alisa\n(jo‘natuvchi)", "#cfe3c8", 9)
quti(ax, 3.0, 2.8, 1.6, 0.7, "Shifrlash\nC = E_K(P)", "#dbe8f5", 9)
quti(ax, 7.0, 2.8, 1.6, 0.7, "Shifrni ochish\nP = D_K(C)", "#dbe8f5", 9)
quti(ax, 9.1, 2.8, 1.5, 0.7, "Bob\n(qabul qiluvchi)", "#cfe3c8", 9)
quti(ax, 5.0, 0.8, 2.6, 0.8, "Tridi (kriptotahlilchi):\nC ni ushlaydi, P yoki K ni izlaydi", "#f6d7c3", 8)
quti(ax, 5.0, 3.7, 3.8, 0.45, "Maxfiy kalit K (himoyalangan kanal)", "#fff4c2", 8)
strelka(ax, 1.65, 2.8, 2.2, 2.8, "P", 0.05)
strelka(ax, 3.8, 2.8, 6.2, 2.8, "C (ochiq kanal)", 0.05)
strelka(ax, 7.8, 2.8, 8.35, 2.8, "P", 0.05)
strelka(ax, 5.0, 2.8, 5.0, 1.22)
strelka(ax, 3.3, 3.55, 3.0, 3.17); strelka(ax, 6.7, 3.55, 7.0, 3.17)
rasm_saqla(fig, "bob01", "aloqa_modeli")
