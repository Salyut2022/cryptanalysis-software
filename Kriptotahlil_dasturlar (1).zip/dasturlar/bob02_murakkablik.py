# -*- coding: utf-8 -*-
"""2-bob: kalit uzunligi va to'liq tanlash vaqti, algoritmlar murakkabligi sinflarining o'sishi."""
import math
import numpy as np
import matplotlib.pyplot as plt
from umumiy import rasm_saqla, jadval_yoz

YIL = 365.25 * 24 * 3600
TEZLIKLAR = {"10⁹ kalit/s (bitta yadro)": 1e9,
             "10¹² kalit/s (GPU klasteri)": 1e12,
             "10¹⁸ kalit/s (gipotetik superkompyuter)": 1e18}


SUP = str.maketrans("0123456789-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻")


def daraja(x):
    """1.2e+17 -> '1,2·10¹⁷' ko'rinishi."""
    m, e = f"{x:.2e}".split("e")
    return f"{m.replace('.', ',')}·10{str(int(e)).translate(SUP)}"


def vaqt_matn(sekund):
    """Sekundlarni o'qish uchun qulay ko'rinishga keltiradi."""
    if sekund < 1e-3:
        return "< 1 ms"
    for chegara, bolinma, birlik in ((60, 1, "s"), (3600, 60, "daqiqa"),
                                    (86400, 3600, "soat"), (YIL, 86400, "kun")):
        if sekund < chegara:
            return f"{sekund / bolinma:.3g} {birlik}".replace(".", ",")
    y = sekund / YIL
    if y < 100:
        return f"{y:.3g} yil".replace(".", ",")
    if y < 1e5:
        return f"{y:,.0f} yil".replace(",", " ")
    return f"10{str(round(math.log10(y))).translate(SUP)} yil"


# 1) jadval: o'rtacha to'liq tanlash vaqti (kalitlar fazosining yarmi)
uzunliklar = [40, 56, 64, 80, 112, 128, 192, 256]
qatorlar = []
for n in uzunliklar:
    q = [n, daraja(2.0 ** n)]
    for v in TEZLIKLAR.values():
        q.append(vaqt_matn(2.0 ** (n - 1) / v))
    qatorlar.append(q)
jadval_yoz("bob02", "toliq_tanlash_vaqti",
           ["Kalit uzunligi (bit)", "Kalitlar soni"] + list(TEZLIKLAR.keys()), qatorlar)

# 2) grafik: log10(vaqt, yil) kalit uzunligiga bog'liq
n = np.arange(32, 257)
fig, ax = plt.subplots(figsize=(7, 4))
for nom, v in TEZLIKLAR.items():
    ax.plot(n, (n - 1) * math.log10(2) - math.log10(v) - math.log10(YIL), label=nom)
ax.axhline(math.log10(1.38e10), color="k", ls="--", lw=1)
ax.text(36, math.log10(1.38e10) + 2, "Koinot yoshi ≈ 1,38·10¹⁰ yil", fontsize=8)
ax.axhline(0, color="gray", ls=":", lw=1)
ax.text(36, 1.5, "1 yil", fontsize=8, color="gray")
ax.set_xlabel("Kalit uzunligi, bit"); ax.set_ylabel("lg(o‘rtacha tanlash vaqti, yil)")
ax.legend(fontsize=8)
rasm_saqla(fig, "bob02", "toliq_tanlash_grafik")

# 3) grafik: murakkablik sinflari
x = np.arange(2, 65)
fig, ax = plt.subplots(figsize=(7, 4))
ax.semilogy(x, x, label="O(n) – chiziqli")
ax.semilogy(x, x ** 2, label="O(n²) – polinomial")
ax.semilogy(x, x ** 3, label="O(n³) – polinomial")
ax.semilogy(x, np.exp(1.9 * (x * np.log(2)) ** (1 / 3) * np.log(x * np.log(2)) ** (2 / 3)),
            label=r"$e^{c\,n^{1/3}(\ln n)^{2/3}}$ – subeksponensial")
ax.semilogy(x, 2.0 ** x, label="O(2ⁿ) – eksponensial")
ax.set_xlabel("Kirish ma’lumoti o‘lchami n, bit"); ax.set_ylabel("Amallar soni (logarifmik shkala)")
ax.legend(fontsize=8)
rasm_saqla(fig, "bob02", "murakkablik_sinflari")
