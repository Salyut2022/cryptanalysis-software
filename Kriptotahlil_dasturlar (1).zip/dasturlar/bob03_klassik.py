# -*- coding: utf-8 -*-
"""3-bob: klassik shifrlarning kriptotahlili.
  1) o'zbek tili (lotin yozuvi) harflari chastotasi va moslik indeksi;
  2) Sezar shifrini xi-kvadrat mezoni bilan ochish;
  3) Vijiner shifrini Kasiski usuli, moslik indeksi va chastotaviy tahlil bilan ochish;
  4) oddiy o'rniga qo'yish shifrini bigramma statistikasi va "tepalikka chiqish" algoritmi bilan ochish;
  5) ustunli o'rin almashtirish shifrini barcha o'rin almashtirishlarni saralash bilan ochish.
Statistik ma'lumotlar o'quv qo'llanma matnidan olingan korpus (korpus.txt) asosida hisoblanadi."""
import math
import random
import re
import itertools
from collections import Counter
from functools import reduce
import matplotlib.pyplot as plt
from umumiy import rasm_saqla, jadval_yoz, matn_yoz, ASOSIY
import os

ALIFBO = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
random.seed(2026)


def tozala(matn):
    """Faqat lotin harflarini qoldiradi (o‘, g‘ dagi tutuq belgisi tashlab yuboriladi)."""
    return re.sub(r"[^A-Z]", "", matn.upper())


KORPUS = tozala(open(os.path.join(ASOSIY, "korpus.txt"), encoding="utf-8").read())

OCHIQ_MATN = tozala("""
Kriptologiya tarixi ming yillar davomida shifr yaratuvchilar va shifr ochuvchilar o‘rtasidagi
musobaqa sifatida rivojlanib kelgan. Qadimgi davrda harflarning o‘rnini almashtirish yoki ularni
boshqa harflar bilan almashtirish yetarli himoya hisoblangan. Biroq to‘qqizinchi asrda yashagan
arab olimi al-Kindiy matndagi harflarning takrorlanish chastotasini hisoblash orqali bunday
shifrlarni ochish mumkinligini ko‘rsatib berdi. Shundan so‘ng ko‘p alifboli shifrlar paydo bo‘ldi
va ular uzoq vaqt davomida ochilmaydigan shifrlar deb hisoblandi. O‘n to‘qqizinchi asrda Kasiski
va Bebbij takrorlanuvchi bo‘laklar orasidagi masofani tahlil qilib, kalit uzunligini aniqlash
usulini taklif qildilar. Yigirmanchi asrda elektromexanik shifrlash mashinalari yaratildi, ammo
matematiklar va muhandislarning birgalikdagi mehnati natijasida ular ham ochildi. Bugungi kunda
shifrlash algoritmlari ochiq e’lon qilinadi va ularning xavfsizligi faqat kalitning maxfiyligiga
tayanadi. Shunga qaramay, har bir yangi algoritm mutaxassislar tomonidan har tomonlama tahlil
qilinadi, chunki birgina e’tibordan chetda qolgan zaiflik butun tizimning xavfsizligini yo‘qqa
chiqarishi mumkin. Shu sababli kriptotahlil kriptografiyaning ajralmas qismi bo‘lib qolmoqda.
Talabalar klassik shifrlarni tahlil qilish orqali zamonaviy usullarning asosiy g‘oyalarini
osonroq tushunib oladilar, chunki statistik qonuniyatlardan foydalanish g‘oyasi o‘zgarmagan.
""")

# ------------------------------------------------ 1. chastotalar
sanoq = Counter(KORPUS)
N = len(KORPUS)
UZ = {h: sanoq[h] / N for h in ALIFBO}
EN = dict(zip(ALIFBO, [8.17, 1.49, 2.78, 4.25, 12.70, 2.23, 2.02, 6.09, 6.97, 0.15, 0.77, 4.03, 2.41,
                       6.75, 7.51, 1.93, 0.10, 5.99, 6.33, 9.06, 2.76, 0.98, 2.36, 0.15, 1.97, 0.07]))
EN = {h: v / 100 for h, v in EN.items()}

tartib = sorted(ALIFBO, key=lambda h: -UZ[h])
fig, ax = plt.subplots(figsize=(8, 3.6))
ax.bar(range(26), [UZ[h] * 100 for h in tartib], color="#3b6ea5")
ax.set_xticks(range(26)); ax.set_xticklabels(tartib)
ax.set_ylabel("Nisbiy chastota, %"); ax.set_title(f"O‘zbek tili (lotin yozuvi) harflari chastotasi, korpus: {N} ta harf")
rasm_saqla(fig, "bob03", "uzbek_chastota")

qatorlar = []
for i in range(7):
    q = []
    for j in range(4):
        idx = i + 7 * j
        q += [tartib[idx], f"{UZ[tartib[idx]] * 100:.2f}".replace(".", ",")] if idx < 26 else ["", ""]
    qatorlar.append(q)
jadval_yoz("bob03", "uzbek_chastota", ["Harf", "%"] * 4, qatorlar)


def moslik_indeksi(t):
    c = Counter(t); n = len(t)
    return sum(v * (v - 1) for v in c.values()) / (n * (n - 1))


IC_UZ = moslik_indeksi(KORPUS)
IC_EN = sum(p * p for p in EN.values())
tasodifiy = "".join(random.choice(ALIFBO) for _ in range(len(KORPUS)))
jadval_yoz("bob03", "moslik_indeksi", ["Matn turi", "Moslik indeksi"],
           [["O‘zbek tili (korpus)", f"{IC_UZ:.4f}".replace(".", ",")], ["Ingliz tili (standart chastotalar)", f"{IC_EN:.4f}".replace(".", ",")],
            ["Tekis taqsimlangan tasodifiy matn", f"{moslik_indeksi(tasodifiy):.4f}".replace(".", ",")],
            ["Nazariy qiymat 1/26", f"{1 / 26:.4f}".replace(".", ",")]])


# ------------------------------------------------ 2. Sezar shifri
def sezar(t, k):
    return "".join(ALIFBO[(ALIFBO.index(c) + k) % 26] for c in t)


def xi_kvadrat(t, model=UZ):
    c = Counter(t); n = len(t)
    return sum((c[h] - n * model[h]) ** 2 / (n * model[h]) for h in ALIFBO if model[h] > 0)


C = sezar(OCHIQ_MATN[:300], 7)
xi = [xi_kvadrat(sezar(C, -k)) for k in range(26)]
fig, ax = plt.subplots(figsize=(8, 3.2))
ax.bar(range(26), xi, color=["#c0392b" if k == min(range(26), key=lambda i: xi[i]) else "#1f5c99" for k in range(26)])
ax.set_xticks(range(26)); ax.set_xlabel("Sinab ko‘rilgan siljish k"); ax.set_ylabel("χ² qiymati")
ax.set_title("Sezar shifrini ochish: eng kichik χ² to‘g‘ri kalitga mos keladi")
rasm_saqla(fig, "bob03", "sezar_xi2")
matn_yoz("bob03", "sezar", f"Shifrmatn (boshi): {C[:60]}\nEng kichik χ²: k = {xi.index(min(xi))}\n"
         f"Ochilgan matn (boshi): {sezar(C, -xi.index(min(xi)))[:60]}")


# ------------------------------------------------ 3. Vijiner shifri
def vijiner(t, kalit, ishora=1):
    return "".join(ALIFBO[(ALIFBO.index(c) + ishora * ALIFBO.index(kalit[i % len(kalit)])) % 26]
                   for i, c in enumerate(t))


KALIT = "XORAZMIY"
CV = vijiner(OCHIQ_MATN, KALIT)

# Kasiski: takrorlanuvchi uchliklar orasidagi masofalar
joylar = {}
for i in range(len(CV) - 2):
    joylar.setdefault(CV[i:i + 3], []).append(i)
masofalar = [b - a for v in joylar.values() if len(v) > 1 for a, b in zip(v, v[1:])]
bolinuvchilar = Counter(d for m in masofalar for d in range(2, 21) if m % d == 0)
jadval_yoz("bob03", "kasiski", ["Taxminiy kalit uzunligi", "Masofalarni bo‘ladigan holatlar soni"],
           [[d, c] for d, c in sorted(bolinuvchilar.items(), key=lambda x: -x[1])[:8]])

ic_lar = [sum(moslik_indeksi(CV[j::m]) for j in range(m)) / m for m in range(1, 21)]
fig, ax = plt.subplots(figsize=(8, 3.2))
ax.bar(range(1, 21), ic_lar, color="#3b6ea5")
ax.axhline(IC_UZ, color="#c0392b", ls="--", lw=1, label=f"O‘zbek tili IC ≈ {IC_UZ:.3f}")
ax.axhline(1 / 26, color="gray", ls=":", lw=1, label="Tasodifiy matn IC ≈ 0,038")
ax.set_xticks(range(1, 21)); ax.set_xlabel("Taxminiy kalit uzunligi m"); ax.set_ylabel("Ustunlarning o‘rtacha IC")
ax.legend(fontsize=8)
rasm_saqla(fig, "bob03", "vijiner_ic")

m = max(range(1, 21), key=lambda i: ic_lar[i - 1] - 0.002 * i)  # kichik uzunliklarga ustunlik
topilgan = "".join(ALIFBO[min(range(26), key=lambda k: xi_kvadrat(sezar(CV[j::m], -k)))] for j in range(m))
matn_yoz("bob03", "vijiner",
         f"Kalit: {KALIT}; shifrmatn uzunligi: {len(CV)}\nShifrmatn (boshi): {CV[:60]}\n"
         f"IC bo‘yicha kalit uzunligi: {m}\nTopilgan kalit: {topilgan}\n"
         f"Ochilgan matn (boshi): {vijiner(CV, topilgan, -1)[:60]}")

# ------------------------------------------------ 4. oddiy o'rniga qo'yish
bigr = Counter(KORPUS[i:i + 2] for i in range(N - 1))
jami = sum(bigr.values())
LOG = {a + b: math.log10((bigr[a + b] + 0.5) / jami) for a in ALIFBO for b in ALIFBO}


def baho(t):
    return sum(LOG[t[i:i + 2]] for i in range(len(t) - 1))


def qoyish(t, kalit):  # kalit: 26 harfli o'rin almashtirish (ochiq -> shifr)
    return t.translate(str.maketrans(ALIFBO, kalit))


kalit_asl = "".join(random.sample(ALIFBO, 26))
CS = qoyish(OCHIQ_MATN, kalit_asl)
teskari_asl = "".join(ALIFBO[kalit_asl.index(h)] for h in ALIFBO)  # shifr -> ochiq

# boshlang'ich kalit: chastotalar bo'yicha moslashtirish
shifr_tartib = [h for h, _ in Counter(CS).most_common()] + [h for h in ALIFBO if h not in CS]
k = [""] * 26
for s_h, o_h in zip(shifr_tartib, tartib):
    k[ALIFBO.index(s_h)] = o_h
kalit = "".join(k)
eng_yaxshi, eng_baho = kalit, baho(qoyish(CS, kalit))
tarix = [(0, eng_baho, qoyish(CS, kalit)[:48])]
for qadam in range(1, 20001):
    i, j = random.sample(range(26), 2)
    l = list(eng_yaxshi); l[i], l[j] = l[j], l[i]
    yangi = "".join(l); b = baho(qoyish(CS, yangi))
    if b > eng_baho:
        eng_yaxshi, eng_baho = yangi, b
    if qadam in (200, 1000, 3000, 20000):
        tarix.append((qadam, eng_baho, qoyish(CS, eng_yaxshi)[:48]))
aniqlik = sum(a == b for a, b in zip(qoyish(CS, eng_yaxshi), OCHIQ_MATN)) / len(OCHIQ_MATN)
jadval_yoz("bob03", "qoyish_tepalik", ["Iteratsiya", "Baho (log₁₀)", "Joriy ochiq matn (boshi)"],
           [[q, f"{b:.1f}".replace(".", ","), t] for q, b, t in tarix])
matn_yoz("bob03", "qoyish", f"Shifrmatn (boshi): {CS[:48]}\nTo‘g‘ri tiklangan harflar ulushi: {aniqlik * 100:.1f}%")


# ------------------------------------------------ 5. ustunli o'rin almashtirish
def ustunli_shifrla(t, tartib_):
    m = len(tartib_)
    t = t + "X" * (-len(t) % m)
    return "".join(t[j::m] for j in tartib_)


def ustunli_och(c, tartib_):
    m = len(tartib_); n = len(c) // m
    ustun = {j: c[i * n:(i + 1) * n] for i, j in enumerate(tartib_)}
    return "".join(ustun[j][r] for r in range(n) for j in range(m))


TARTIB = (4, 1, 5, 0, 3, 2)
CT = ustunli_shifrla(OCHIQ_MATN[:420], TARTIB)
natija = sorted(((baho(ustunli_och(CT, p)), p) for p in itertools.permutations(range(6))), reverse=True)
jadval_yoz("bob03", "ustunli", ["O‘rin", "Ustunlar tartibi", "Baho (log₁₀)", "Ochilgan matn (boshi)"],
           [[i + 1, "".join(map(str, p)), f"{b:.1f}".replace(".", ","), ustunli_och(CT, p)[:36]]
            for i, (b, p) in enumerate(natija[:5])])
matn_yoz("bob03", "ustunli_ic", f"Shifrmatn IC = {moslik_indeksi(CT):.4f} (ochiq matn IC = "
         f"{moslik_indeksi(OCHIQ_MATN[:420]):.4f}); tekshirilgan tartiblar soni: {len(natija)}")
