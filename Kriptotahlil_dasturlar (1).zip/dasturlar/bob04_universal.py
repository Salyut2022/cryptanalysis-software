# -*- coding: utf-8 -*-
"""4-bob: kriptotahlilning universal usullari.
  1) to'liq tanlash va yagonalik masofasi (TDES misolida);
  2) tug'ilgan kunlar paradoksi: nazariy va tajribaviy ehtimollik;
  3) "o'rtada uchrashish" hujumi: ikki karra TDES (32 bitli kalit);
  4) Pollard rho usulidagi ketma-ketlik ("rho" shakli)."""
import math
import random
import time
import numpy as np
import matplotlib.pyplot as plt
from shifrlar import tdes_shifrla, tdes_ochish
from umumiy import rasm_saqla, jadval_yoz, matn_yoz

random.seed(7)

# ------------------------------------------------ 1. to'liq tanlash va yagonalik
kalit = random.randrange(1 << 16)
juftlar = [(p, tdes_shifrla(p, kalit)) for p in random.sample(range(1 << 16), 4)]
t0 = time.time()
nomzodlar = list(range(1 << 16))
qatorlar = []
for n, (p, c) in enumerate(juftlar, 1):
    nomzodlar = [k for k in nomzodlar if tdes_shifrla(p, k) == c]
    qatorlar.append([n, len(nomzodlar), "ha" if kalit in nomzodlar else "yo‘q"])
vaqt = time.time() - t0
jadval_yoz("bob04", "yagonalik", ["Ma’lum (P, C) juftliklar soni", "Mos keluvchi kalitlar soni", "To‘g‘ri kalit ro‘yxatda"], qatorlar)
matn_yoz("bob04", "toliq_tanlash",
         f"Haqiqiy kalit: {kalit:04X}; 2^16 kalitni Python’da tekshirish vaqti: "
         f"{vaqt:.1f} s".replace(".", ",") + f"; tezlik ≈ {65536 / vaqt:,.0f} kalit/s".replace(",", " "))

# ------------------------------------------------ 2. tug'ilgan kunlar paradoksi
N = 365
k = np.arange(1, 81)
aniq = 1 - np.array([np.prod(1 - np.arange(i) / N) for i in k])
taqribiy = 1 - np.exp(-k * (k - 1) / (2 * N))
tajriba = []
for kk in k:
    t = 2000
    tajriba.append(sum(len(set(random.randrange(N) for _ in range(kk))) < kk for _ in range(t)) / t)
fig, ax = plt.subplots(figsize=(7, 3.8))
ax.plot(k, aniq, label="Aniq formula")
ax.plot(k, taqribiy, "--", label=r"Taqribiy: $1-e^{-k(k-1)/2N}$")
ax.plot(k, tajriba, ".", ms=4, label="Tajriba (2000 marta takrorlash)")
ax.axhline(0.5, color="gray", ls=":"); ax.axvline(23, color="gray", ls=":")
ax.text(24, 0.05, "k = 23", fontsize=8)
ax.set_xlabel("Guruhdagi kishilar soni k"); ax.set_ylabel("Kamida bitta moslik ehtimolligi")
ax.legend(fontsize=8)
rasm_saqla(fig, "bob04", "tugilgan_kun")

# ------------------------------------------------ 3. o'rtada uchrashish (2-TDES)
k1, k2 = random.randrange(1 << 16), random.randrange(1 << 16)
P = [random.randrange(1 << 16) for _ in range(3)]
C = [tdes_shifrla(tdes_shifrla(p, k1), k2) for p in P]
t0 = time.time()
jadval = {}
for a in range(1 << 16):                          # oldinga: X = E_a(P1)
    jadval.setdefault(tdes_shifrla(P[0], a), []).append(a)
mos = [(a, b) for b in range(1 << 16) for a in jadval.get(tdes_ochish(C[0], b), [])]  # orqaga: D_b(C1)
t_mitm = time.time() - t0
qolgan2 = [(a, b) for a, b in mos if tdes_shifrla(tdes_shifrla(P[1], a), b) == C[1]]
qolgan3 = [(a, b) for a, b in qolgan2 if tdes_shifrla(tdes_shifrla(P[2], a), b) == C[2]]
jadval_yoz("bob04", "mitm",
           ["Ko‘rsatkich", "Qiymat"],
           [["Haqiqiy kalit juftligi (k₁, k₂)", f"({k1:04X}, {k2:04X})"],
            ["Jadval hajmi (xotira)", "2¹⁶ = 65 536 yozuv"],
            ["Shifrlash/ochish amallari", "2·2¹⁶ ≈ 1,3·10⁵ (to‘liq tanlashda 2³² ≈ 4,3·10⁹)"],
            ["1-juftlik bo‘yicha nomzodlar", len(mos)],
            ["2-juftlik tekshiruvidan keyin", len(qolgan2)],
            ["3-juftlik tekshiruvidan keyin", f"{len(qolgan3)}: " + ", ".join(f"({a:04X}, {b:04X})" for a, b in qolgan3)],
            ["Hujum vaqti (Python)", f"{t_mitm:.1f} s".replace(".", ",")]])


# ------------------------------------------------ 4. rho shakli
def f(x, p=479):
    return (x * x + 1) % p


x, korilgan, ketma = 2, {}, []
while x not in korilgan:
    korilgan[x] = len(ketma); ketma.append(x); x = f(x)
mu, lam = korilgan[x], len(ketma) - korilgan[x]
fig, ax = plt.subplots(figsize=(4.6, 5.6))
dum = [(0, -(mu - i)) for i in range(mu)]
r = lam / (2 * math.pi) * 1.0
halqa = [(r * math.sin(2 * math.pi * j / lam), r - r * math.cos(2 * math.pi * j / lam)) for j in range(lam)]
nuqta = dum + halqa
xs, ys = zip(*nuqta)
ax.plot(list(xs) + [xs[mu]], list(ys) + [ys[mu]], "-o", ms=4, color="#3b6ea5")
for i, siljish in ((0, (6, -3)), (mu, (-58, -3)), (len(nuqta) - 1, (6, -8))):
    ax.annotate(f"x{i} = {ketma[i]}", nuqta[i], textcoords="offset points", xytext=siljish, fontsize=7)
ax.set_title(f"xᵢ₊₁ = xᵢ² + 1 mod 479, x₀ = 2\ndum uzunligi μ = {mu}, sikl uzunligi λ = {lam}", fontsize=9)
ax.axis("equal"); ax.axis("off")
rasm_saqla(fig, "bob04", "rho_shakli")

# Floyd usuli bilan siklni topish (xotira O(1))
t, h, qadam = f(2), f(f(2)), 1
while t != h:
    t, h, qadam = f(t), f(f(h)), qadam + 1
matn_yoz("bob04", "floyd", f"Floyd usuli {qadam} qadamda uchrashuvni topdi (μ={mu}, λ={lam}, √p ≈ {math.sqrt(479):.0f})")
