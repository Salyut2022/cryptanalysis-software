# -*- coding: utf-8 -*-
"""5-bob: psevdotasodifiy sonlar generatorlarining kriptotahlili.
  1) RANDU chiziqli kongruent generatorining tekisliklar tuzilmasi;
  2) chiziqli kongruent generator (ChKG) parametrlarini chiqish qiymatlari bo'yicha tiklash va bashorat qilish;
  3) Berlekemp-Messi algoritmi: LFSR ni 2L bit bo'yicha tiklash, chiziqli murakkablik profili;
  4) Geffe generatoriga korrelyatsion hujum;
  5) NIST SP 800-22 dagi ayrim statistik testlar (monobit, blokli chastota, seriyalar);
  6) RC4 ning ikkinchi chiqish baytidagi siljish (Mantin-Shamir)."""
import math
import random
import secrets
from functools import reduce
import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erfc, gammaincc
from umumiy import rasm_saqla, jadval_yoz, matn_yoz

random.seed(5)

# ------------------------------------------------ 1. RANDU
x, qiymatlar = 1, []
for _ in range(30002):
    x = (65539 * x) % 2 ** 31
    qiymatlar.append(x)
v = np.array(qiymatlar, dtype=np.int64)
proj = (9 * v[:-2] - 6 * v[1:-1] + v[2:]) / 2 ** 31          # RANDU uchun butun son bo'ladi
yaxshi = np.frombuffer(secrets.token_bytes(4 * 30002), dtype=np.uint32).astype(np.int64) % 2 ** 31
proj2 = (9 * yaxshi[:-2] - 6 * yaxshi[1:-1] + yaxshi[2:]) / 2 ** 31
fig, axs = plt.subplots(1, 2, figsize=(9, 3.4), sharey=True)
axs[0].plot(v[:-2] / 2 ** 31, proj, ",", color="#c0392b")
axs[0].set_title("RANDU: xₖ₊₂ = 6xₖ₊₁ − 9xₖ (mod 1)\nnuqtalar 15 ta tekislikda yotadi", fontsize=9)
axs[1].plot(yaxshi[:-2] / 2 ** 31, proj2, ",", color="#3b6ea5")
axs[1].set_title("Kriptografik generator (OS manbasi)\nhech qanday tuzilma yo‘q", fontsize=9)
for a in axs:
    a.set_xlabel("xₖ / 2³¹")
axs[0].set_ylabel("(9xₖ − 6xₖ₊₁ + xₖ₊₂) / 2³¹")
rasm_saqla(fig, "bob05", "randu")
matn_yoz("bob05", "randu", f"RANDU proyeksiyasining turli qiymatlari soni: {len(set(np.round(proj).astype(int)))}")

# ------------------------------------------------ 2. ChKG parametrlarini tiklash
a0, c0, m0 = 1103515245, 12345, 2 ** 31
x, kuz = 20260906, []
for _ in range(12):
    x = (a0 * x + c0) % m0
    kuz.append(x)
ochiq = kuz[:7]                                     # hujumchi faqat 7 ta qiymatni ko'radi
t = [b - a for a, b in zip(ochiq, ochiq[1:])]
u = [abs(t[i + 2] * t[i] - t[i + 1] ** 2) for i in range(len(t) - 2)]
m = reduce(math.gcd, u)
a = (t[1] * pow(t[0], -1, m)) % m if math.gcd(t[0], m) == 1 else None
if a is None:  # t0 juft bo'lsa, m ning toq qismi bo'yicha yechiladi va moslar tekshiriladi
    for cand in range(m):
        if (cand * t[0] - t[1]) % m == 0 and all((cand * t[i] - t[i + 1]) % m == 0 for i in range(len(t) - 1)):
            a = cand; break
c = (ochiq[1] - a * ochiq[0]) % m
bashorat, x = [], ochiq[-1]
for _ in range(5):
    x = (a * x + c) % m
    bashorat.append(x)
jadval_yoz("bob05", "chkg_tiklash", ["Parametr", "Haqiqiy qiymat", "Tiklangan qiymat"],
           [["Modul m", m0, m], ["Ko‘paytuvchi a", a0, a], ["Qo‘shiluvchi c", c0, c],
            ["Keyingi 5 qiymat", ", ".join(map(str, kuz[7:])), ", ".join(map(str, bashorat))]])


# ------------------------------------------------ 3. LFSR va Berlekemp-Messi
def lfsr(holat, teskari_aloqa, n):
    """Fibonachchi LFSR. teskari_aloqa: s[t+L] = XOR s[t+L-i], i ∈ teskari_aloqa."""
    s = list(holat)
    L = len(s)
    while len(s) < n:
        s.append(reduce(lambda p, q: p ^ q, (s[-i] for i in teskari_aloqa)))
    return s[:n]


def berlekamp_massey(s):
    n = len(s); C = [1] + [0] * n; B = [1] + [0] * n
    L, m_, profil = 0, -1, []
    for N_ in range(n):
        d = s[N_]
        for i in range(1, L + 1):
            d ^= C[i] & s[N_ - i]
        if d:
            T = C[:]
            for i in range(n - N_ + m_):
                C[N_ - m_ + i] ^= B[i]
            if 2 * L <= N_:
                L, m_, B = N_ + 1 - L, N_, T
        profil.append(L)
    return L, C[:L + 1], profil


L_asl, taps = 17, (17, 3)  # x^17 + x^3 + 1 (primitiv ko'phad)
s = lfsr([random.randint(0, 1) for _ in range(L_asl)], taps, 300)
L, C, profil = berlekamp_massey(s[:2 * L_asl])
qayta = list(s[:L])
while len(qayta) < 300:
    qayta.append(reduce(lambda p, q: p ^ q, (C[i] & qayta[-i] for i in range(1, L + 1))))
tasodif = [secrets.randbits(1) for _ in range(300)]
_, _, profil_t = berlekamp_massey(tasodif)
_, _, profil_l = berlekamp_massey(s)
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.step(range(1, 301), profil_l, where="post", label="LFSR (L = 17) ketma-ketligi")
ax.step(range(1, 301), profil_t, where="post", label="Kriptografik generator ketma-ketligi")
ax.plot([1, 300], [0.5, 150], "k:", lw=1, label="n/2 chizig‘i")
ax.set_xlabel("Ketma-ketlik uzunligi n"); ax.set_ylabel("Chiziqli murakkablik L(n)")
ax.legend(fontsize=8)
rasm_saqla(fig, "bob05", "chiziqli_murakkablik")
kophad = " + ".join(["1"] + [f"x^{i}" for i in range(1, L + 1) if C[i]])
matn_yoz("bob05", "bm", f"BM natijasi: L = {L}, C(x) = {kophad}; keyingi bitlar to‘g‘ri bashorat qilindi: {qayta == s}")


# ------------------------------------------------ 4. Geffe generatori
def davr(taps, L):
    s0 = [1] + [0] * (L - 1); s = lfsr(s0, taps, 2 ** L + L)
    return next(p for p in range(1, 2 ** L) if s[p:p + L] == s0)


REG = [(7, (7, 6)), (11, (11, 9)), (13, (13, 4, 3, 1))]
for L_, tp in REG:
    assert davr(tp, L_) == 2 ** L_ - 1, (L_, tp)       # maksimal davr tekshiruvi
hol = [[random.randint(0, 1) for _ in range(L_)] for L_, _ in REG]
hol = [h if any(h) else [1] + h[1:] for h in hol]
NB = 400
x1, x2, x3 = (lfsr(h, tp, NB) for h, (_, tp) in zip(hol, REG))
z = [(p & q) ^ ((1 - p) & r) for p, q, r in zip(x1, x2, x3)]


def eng_mos(idx):
    L_, tp = REG[idx]; natija = []
    for k in range(1, 2 ** L_):
        h = [(k >> (L_ - 1 - i)) & 1 for i in range(L_)]
        natija.append((sum(a == b for a, b in zip(lfsr(h, tp, NB), z)) / NB, h))
    return natija


r2, r3 = eng_mos(1), eng_mos(2)
h2 = max(r2)[1]; h3 = max(r3)[1]
y2, y3 = lfsr(h2, REG[1][1], NB), lfsr(h3, REG[2][1], NB)
h1 = None
for k in range(1, 2 ** 7):
    h = [(k >> (6 - i)) & 1 for i in range(7)]
    y1 = lfsr(h, REG[0][1], NB)
    if all(((p & q) ^ ((1 - p) & r)) == w for p, q, r, w in zip(y1, y2, y3, z)):
        h1 = h; break
fig, ax = plt.subplots(figsize=(7, 3.4))
ax.hist([m_ for m_, _ in r3], bins=60, color="#1f5c99")
ax.axvline(max(r3)[0], color="#c0392b", ls="--", label=f"Haqiqiy holat: {max(r3)[0]:.3f}".replace(".", ","))
ax.set_xlabel("z bilan mos kelgan bitlar ulushi"); ax.set_ylabel("Nomzod holatlar soni")
ax.set_title("Geffe generatori: 3-registrning 8191 ta boshlang‘ich holati bo‘yicha moslik", fontsize=9)
ax.legend(fontsize=8)
rasm_saqla(fig, "bob05", "geffe")
jadval_yoz("bob05", "geffe", ["Registr", "Uzunligi", "Tekshirilgan holatlar", "Eng yuqori moslik", "Holat to‘g‘ri tiklandimi"],
           [["LFSR-2", 11, 2 ** 11 - 1, f"{max(r2)[0]:.3f}".replace(".", ","), "ha" if h2 == hol[1] else "yo‘q"],
            ["LFSR-3", 13, 2 ** 13 - 1, f"{max(r3)[0]:.3f}".replace(".", ","), "ha" if h3 == hol[2] else "yo‘q"],
            ["LFSR-1", 7, 2 ** 7 - 1, "1,000 (to‘liq mos)", "ha" if h1 == hol[0] else "yo‘q"]])


# ------------------------------------------------ 5. statistik testlar
def monobit(b):
    n = len(b); S = sum(2 * x - 1 for x in b)
    return erfc(abs(S) / math.sqrt(n) / math.sqrt(2))


def blokli_chastota(b, M=128):
    N_ = len(b) // M
    chi = 4 * M * sum((sum(b[i * M:(i + 1) * M]) / M - 0.5) ** 2 for i in range(N_))
    return gammaincc(N_ / 2, chi / 2)


def seriyalar(b):
    n = len(b); pi = sum(b) / n
    if abs(pi - 0.5) >= 2 / math.sqrt(n):
        return 0.0
    V = 1 + sum(b[i] != b[i + 1] for i in range(n - 1))
    return erfc(abs(V - 2 * n * pi * (1 - pi)) / (2 * math.sqrt(2 * n) * pi * (1 - pi)))


def rc4(kalit, n):
    S = list(range(256)); j = 0
    for i in range(256):
        j = (j + S[i] + kalit[i % len(kalit)]) & 255; S[i], S[j] = S[j], S[i]
    i = j = 0; out = []
    for _ in range(n):
        i = (i + 1) & 255; j = (j + S[i]) & 255; S[i], S[j] = S[j], S[i]
        out.append(S[(S[i] + S[j]) & 255])
    return out


def baytdan_bit(bs):
    return [(b >> (7 - k)) & 1 for b in bs for k in range(8)]


n = 100000
x = 12345; chkg = []
for _ in range(n):
    x = (a0 * x + c0) % m0; chkg.append(x & 1)
generatorlar = {
    "OS kriptografik generatori (secrets)": baytdan_bit(secrets.token_bytes(n // 8)),
    "RC4 kalit oqimi": baytdan_bit(rc4(secrets.token_bytes(16), n // 8)),
    "ChKG (m = 2³¹) ning kichik biti": chkg,
    "LFSR, L = 17": lfsr([1] + [0] * 16, taps, n),
    "Siljigan generator, P(1) = 0,51": [int(random.random() < 0.51) for _ in range(n)],
}
qator = []
for nom, b in generatorlar.items():
    p = [monobit(b), blokli_chastota(b), seriyalar(b)]
    qator.append([nom] + [f"{x:.3f}".replace(".", ",") for x in p] + ["o‘tdi" if min(p) >= 0.01 else "o‘tmadi"])
jadval_yoz("bob05", "statistik_testlar", ["Generator (n = 100 000 bit)", "Monobit, P", "Blokli chastota, P", "Seriyalar, P", "Xulosa (α = 0,01)"], qator)

# ------------------------------------------------ 6. RC4 ikkinchi bayti
SON = 60000
ikkinchi = np.zeros(256)
for _ in range(SON):
    ikkinchi[rc4(secrets.token_bytes(16), 2)[1]] += 1
fig, ax = plt.subplots(figsize=(7, 3.2))
ax.bar(range(256), ikkinchi / SON, width=1.0, color="#1f5c99")
ax.bar([0], [ikkinchi[0] / SON], width=3, color="#c0392b")
ax.axhline(1 / 256, color="k", ls="--", lw=1, label="Ideal qiymat 1/256")
ax.set_xlabel("Ikkinchi chiqish baytining qiymati"); ax.set_ylabel("Nisbiy chastota")
ax.set_title(f"RC4: {SON} ta tasodifiy kalit, P(Z₂ = 0) = {ikkinchi[0] / SON:.4f} ≈ 2/256".replace(".", ","), fontsize=9)
ax.legend(fontsize=8)
rasm_saqla(fig, "bob05", "rc4_siljish")
