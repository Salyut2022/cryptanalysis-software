# -*- coding: utf-8 -*-
"""6-bob: ochiq matn va shifrmatnga asoslangan kriptotahlil.
  1) faqat shifrmatn: takrorlanuvchi kalitli XOR shifrini ochish (Xemming masofasi);
  2) ma'lum ochiq matn: Xill shifri kalitini chiziqli algebra bilan tiklash;
  3) tanlangan ochiq matn: AES-ECB rejimida "baytma-bayt" ochish;
  4) tanlangan shifrmatn: CBC rejimiga to'ldirish orakuli hujumi (Vodene, 2002);
  5) tanlangan shifrmatn: "darslik" RSA ning o'zgaruvchanligi (blinding)."""
import os
import random
import secrets
import time
import matplotlib.pyplot as plt
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from umumiy import rasm_saqla, jadval_yoz, matn_yoz

random.seed(6)
MATN = ("Kriptografik tizimning xavfsizligi algoritmning maxfiyligiga emas, balki kalitning maxfiyligiga "
        "asoslanishi lozim. Bu tamoyil Kerxgoffs prinsipi deb ataladi va zamonaviy kriptografiyaning "
        "asosiy qoidalaridan biri hisoblanadi. Tahlilchi algoritmni to'liq biladi deb faraz qilinadi, "
        "shuning uchun shifrning bardoshliligi faqat kalitlar fazosining kattaligi va algoritmning "
        "matematik xossalari bilan belgilanadi. Hujum modeli tahlilchining imkoniyatlarini aniq ifodalaydi.").encode()


# ------------------------------------------------ 1. takrorlanuvchi kalitli XOR (faqat shifrmatn)
def xor_kalit(m, k):
    return bytes(b ^ k[i % len(k)] for i, b in enumerate(m))


def xemming(a, b):
    return sum(bin(x ^ y).count("1") for x, y in zip(a, b))


KALIT = b"TATU2026"
C1 = xor_kalit(MATN, KALIT)
masofa = []
for m in range(2, 21):
    bloklar = [C1[i * m:(i + 1) * m] for i in range(len(C1) // m)]
    juft = [(bloklar[i], bloklar[i + 1]) for i in range(len(bloklar) - 1)]
    masofa.append(sum(xemming(a, b) for a, b in juft) / len(juft) / m)
fig, ax = plt.subplots(figsize=(7, 3.2))
ax.bar(range(2, 21), masofa, color=["#c0392b" if m == 8 else "#3b6ea5" for m in range(2, 21)])
ax.set_xticks(range(2, 21)); ax.set_xlabel("Taxminiy kalit uzunligi m")
ax.set_ylabel("Normallangan Xemming masofasi")
rasm_saqla(fig, "bob06", "xor_xemming")
m = min(i for i in range(2, 21) if masofa[i - 2] <= 1.05 * min(masofa))  # eng kichik mos uzunlik


def baho(bs):  # ochiq matnning "o'qilishi": kichik harflar, unlilar va bo'shliqlarga ball beriladi
    return sum((chr(b) in "aeiou ") * 2 + chr(b).islower() - 5 * (b < 32 or b > 126) for b in bs)


topilgan = bytes(max(range(256), key=lambda k: baho(bytes(b ^ k for b in C1[j::m]))) for j in range(m))
matn_yoz("bob06", "xor", f"Kalit uzunligi: {m}; topilgan kalit: {topilgan.decode()}; "
         f"ochilgan matn: {xor_kalit(C1, topilgan)[:60].decode()}...")

# ------------------------------------------------ 2. Xill shifri (ma'lum ochiq matn)
A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def hill(t, K):
    v = [A.index(c) for c in t]
    return "".join(A[(K[r][0] * v[i] + K[r][1] * v[i + 1]) % 26] for i in range(0, len(v), 2) for r in (0, 1))


def tes2(M):
    d = (M[0][0] * M[1][1] - M[0][1] * M[1][0]) % 26
    di = pow(d, -1, 26)
    return [[M[1][1] * di % 26, -M[0][1] * di % 26], [-M[1][0] * di % 26, M[0][0] * di % 26]]


K_asl = [[3, 5], [2, 7]]
P = "KRIPTOTAHLIL"; Cx = hill(P, K_asl)
# ikki juftlik bigrammadan P va C matritsalari (ustunlar - bigrammalar), K = C·P^(-1)
for i in range(0, len(P) - 3, 2):
    for j in range(i + 2, len(P) - 1, 2):
        Pm = [[A.index(P[i]), A.index(P[j])], [A.index(P[i + 1]), A.index(P[j + 1])]]
        d = (Pm[0][0] * Pm[1][1] - Pm[0][1] * Pm[1][0]) % 26
        if d % 2 and d % 13:
            Cm = [[A.index(Cx[i]), A.index(Cx[j])], [A.index(Cx[i + 1]), A.index(Cx[j + 1])]]
            Pi = tes2(Pm)
            K = [[sum(Cm[r][t] * Pi[t][c] for t in range(2)) % 26 for c in range(2)] for r in range(2)]
            break
    else:
        continue
    break
jadval_yoz("bob06", "hill", ["Ko‘rsatkich", "Qiymat"],
           [["Ma’lum ochiq matn", P], ["Unga mos shifrmatn", Cx],
            ["Foydalanilgan bigrammalar", f"{P[i:i + 2]}→{Cx[i:i + 2]}, {P[j:j + 2]}→{Cx[j:j + 2]}"],
            ["Tiklangan kalit matritsasi K", str(K)], ["Haqiqiy kalit", str(K_asl)]])

# ------------------------------------------------ 3. ECB, tanlangan ochiq matn
SIR = b"Parol: Q7#tashkent-2026"
K_ECB = secrets.token_bytes(16)


def ecb_orakul(hujumchi_matni):
    """Server: hujumchi matni + maxfiy satrni AES-ECB da shifrlaydi."""
    d = hujumchi_matni + SIR
    d += bytes([16 - len(d) % 16]) * (16 - len(d) % 16)
    e = Cipher(algorithms.AES(K_ECB), modes.ECB()).encryptor()
    return e.update(d) + e.finalize()


tiklangan = b""
sorov = 0
while True:
    tol = b"A" * (15 - len(tiklangan) % 16)
    blok = len(tiklangan) // 16
    nishon = ecb_orakul(tol)[16 * blok:16 * blok + 16]; sorov += 1
    lugat = {}
    for b in range(256):
        lugat[ecb_orakul(tol + tiklangan + bytes([b]))[16 * blok:16 * blok + 16]] = b; sorov += 1
    if nishon not in lugat:
        break
    tiklangan += bytes([lugat[nishon]])
    if len(tiklangan) > 64:
        break
tiklangan = tiklangan.rstrip(b"\x01")
matn_yoz("bob06", "ecb", f"Tiklangan maxfiy satr: {tiklangan.decode()}; orakulga so‘rovlar soni: {sorov}")

# ------------------------------------------------ 4. CBC to'ldirish orakuli
K_CBC = secrets.token_bytes(16)


def cbc_shifrla(m):
    iv = secrets.token_bytes(16)
    m += bytes([16 - len(m) % 16]) * (16 - len(m) % 16)
    e = Cipher(algorithms.AES(K_CBC), modes.CBC(iv)).encryptor()
    return iv + e.update(m) + e.finalize()


def orakul(c):
    """Server faqat to'ldirish to'g'ri yoki noto'g'riligini bildiradi."""
    d = Cipher(algorithms.AES(K_CBC), modes.CBC(c[:16])).decryptor()
    m = d.update(c[16:]) + d.finalize()
    p = m[-1]
    return 1 <= p <= 16 and m[-p:] == bytes([p]) * p


MAXFIY = b"Karta raqami: 8600 1234 5678 9012"
CC = cbc_shifrla(MAXFIY)
bloklar = [CC[i:i + 16] for i in range(0, len(CC), 16)]
ochiq, sorov, t0 = b"", 0, time.time()
for n in range(1, len(bloklar)):
    oldingi, joriy = bloklar[n - 1], bloklar[n]
    oraliq = [0] * 16                                   # D_K(joriy)
    for poz in range(15, -1, -1):
        pad = 16 - poz
        for g in range(256):
            soxta = bytearray(16)
            for k in range(poz + 1, 16):
                soxta[k] = oraliq[k] ^ pad
            soxta[poz] = g
            sorov += 1
            if orakul(bytes(soxta) + joriy):
                if poz == 15:                       # tasodifiy 0x02 0x02 holatini istisno qilish
                    soxta[14] ^= 1
                    sorov += 1
                    if not orakul(bytes(soxta) + joriy):
                        continue
                oraliq[poz] = g ^ pad
                break
    ochiq += bytes(o ^ p for o, p in zip(oraliq, oldingi))
ochiq = ochiq[:-ochiq[-1]]
jadval_yoz("bob06", "padding_oracle", ["Ko‘rsatkich", "Qiymat"],
           [["Shifrmatn bloklari soni (IV dan tashqari)", len(bloklar) - 1],
            ["Orakulga so‘rovlar soni", sorov],
            ["Bir baytga o‘rtacha so‘rov", f"{sorov / (16 * (len(bloklar) - 1)):.1f}".replace(".", ",")],
            ["Tiklangan ochiq matn", ochiq.decode()],
            ["Hujum vaqti", f"{time.time() - t0:.2f} s".replace(".", ",")]])

# ------------------------------------------------ 5. RSA: tanlangan shifrmatn
p, q, e = 1000003, 1000033, 65537
n = p * q; d = pow(e, -1, (p - 1) * (q - 1))
m_sir = 42424242
c = pow(m_sir, e, n)
r = 7
c2 = (c * pow(r, e, n)) % n            # hujumchi shifrmatnni "niqoblaydi"
m2 = pow(c2, d, n)                     # orakul niqoblangan shifrmatnni ochib beradi
m_top = (m2 * pow(r, -1, n)) % n
jadval_yoz("bob06", "rsa_cca", ["Qadam", "Qiymat"],
           [["Ochiq kalit (n, e)", f"({n}, {e})"], ["Ushlangan shifrmatn c", c],
            ["Hujumchi yuborgan c′ = c·rᵉ mod n (r = 7)", c2], ["Orakul javobi m′ = (c′)ᵈ mod n", m2],
            ["m = m′·r⁻¹ mod n", m_top], ["Haqiqiy ochiq matn", m_sir]])
