# -*- coding: utf-8 -*-
"""7-bob: zamonaviy simmetrik shifrlarni umumiy kriptografik talablar asosida baholash.
  1) S-bloklarning kriptografik ko'rsatkichlari: chiziqsizlik, differensial bir xillik,
     algebraik daraja, qat'iy ko'chki mezoni (SAC), bitlar mustaqilligi mezoni (BIC);
  2) AES va o'quv SP-tarmog'ida ko'chki effektining raundlar bo'yicha rivojlanishi;
  3) ECB va CTR rejimlarida tasvirni shifrlash;
  4) shifrlash tezligini o'lchash."""
import os
import random
import secrets
import time
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from shifrlar import (AES_S, DES_S, MAGMA_S, PRESENT_S, SPN_S, TDES_SL, TDES_SR,
                      des_sbox_jadval, aes_shifrla, spn_shifrla)
from umumiy import rasm_saqla, jadval_yoz, matn_yoz

random.seed(77)


def wht(f):
    """Tez Uolsh-Adamar almashtirishi; f - (−1)^g ko'rinishidagi massiv."""
    a = f.astype(np.int64).copy(); h = 1
    while h < len(a):
        a = a.reshape(-1, 2 * h)
        x, y = a[:, :h].copy(), a[:, h:].copy()
        a[:, :h], a[:, h:] = x + y, x - y
        a = a.reshape(-1); h *= 2
    return a


def anf_daraja(tt):
    """Haqiqat jadvalidan algebraik normal shakl (ANF) darajasi."""
    a = np.array(tt, dtype=np.uint8); n = int(np.log2(len(a))); h = 1
    while h < len(a):
        a = a.reshape(-1, 2 * h); a[:, h:] ^= a[:, :h]; a = a.reshape(-1); h *= 2
    return max((bin(i).count("1") for i in range(len(a)) if a[i]), default=0)


def korsatkichlar(S, n, m):
    F = np.array(S); X = np.arange(2 ** n)
    max_w, darajalar = 0, []
    for c in range(1, 2 ** m):
        f = np.array([bin(c & int(v)).count("1") & 1 for v in F])
        max_w = max(max_w, np.abs(wht(1 - 2 * f)).max())
        if bin(c).count("1") == 1:
            darajalar.append(anf_daraja(f))
    NL = 2 ** (n - 1) - max_w // 2
    delta = max(np.bincount(F ^ F[X ^ a], minlength=2 ** m).max() for a in range(1, 2 ** n))
    sac = np.zeros((n, m))
    for i in range(n):
        dif = F ^ F[X ^ (1 << i)]
        for j in range(m):
            sac[i, j] = ((dif >> j) & 1).mean()
    bic = 0.0
    for i in range(n):
        dif = F ^ F[X ^ (1 << i)]
        for j in range(m):
            for k in range(j + 1, m):
                a_, b_ = (dif >> j) & 1, (dif >> k) & 1
                if a_.std() > 0 and b_.std() > 0:
                    bic = max(bic, abs(np.corrcoef(a_, b_)[0, 1]))
    return NL, delta, max(darajalar), np.abs(sac - 0.5).max(), bic


bloklar = [("AES (8→8)", AES_S, 8, 8)]
bloklar += [(f"DES S{i + 1} (6→4)", des_sbox_jadval(t), 6, 4) for i, t in enumerate(DES_S)]
bloklar += [("TDES chap (6→4)", des_sbox_jadval(TDES_SL), 6, 4), ("TDES o‘ng (6→4)", des_sbox_jadval(TDES_SR), 6, 4)]
bloklar += [(f"Magma π{i} (4→4)", t, 4, 4) for i, t in enumerate(MAGMA_S)]
bloklar += [("PRESENT (4→4)", PRESENT_S, 4, 4), ("O‘quv SPN (4→4)", SPN_S, 4, 4)]
tas = list(range(256)); random.shuffle(tas)
bloklar.append(("Tasodifiy o‘rin almashtirish (8→8)", tas, 8, 8))

qatorlar = []
for nom, S, n, m in bloklar:
    NL, d, deg, sac, bic = korsatkichlar(S, n, m)
    qatorlar.append([nom, NL, d, deg, f"{sac:.3f}".replace(".", ","), f"{bic:.3f}".replace(".", ",")])
jadval_yoz("bob07", "sblok_korsatkichlar",
           ["S-blok", "Chiziqsizlik NL", "Diff. bir xillik δ", "Algebraik daraja", "SAC: max|p − 0,5|", "BIC: max|r|"], qatorlar)

# ------------------------------------------------ 2. ko'chki effekti
SON = 150
aes_nat = np.zeros(10)
for _ in range(SON):
    k = secrets.token_bytes(16); p = bytearray(secrets.token_bytes(16))
    _, h1 = aes_shifrla(bytes(p), k, 10, True)
    b = random.randrange(128); p[b // 8] ^= 1 << (b % 8)
    _, h2 = aes_shifrla(bytes(p), k, 10, True)
    aes_nat += [sum(bin(x ^ y).count("1") for x, y in zip(u, v)) for u, v in zip(h1, h2)]
aes_nat /= SON * 128
spn_nat = np.zeros(4)
for _ in range(3000):
    ks = [random.randrange(65536) for _ in range(5)]; p = random.randrange(65536); b = 1 << random.randrange(16)
    for r in range(1, 5):
        spn_nat[r - 1] += bin(spn_shifrla(p, ks[:r] + [0], r) ^ spn_shifrla(p ^ b, ks[:r] + [0], r)).count("1")
spn_nat /= 3000 * 16
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.plot(range(1, 11), aes_nat, "o-", label="AES-128 (128 bit)")
ax.plot(range(1, 5), spn_nat, "s-", label="O‘quv SP-tarmog‘i (16 bit)")
ax.axhline(0.5, color="gray", ls="--", lw=1, label="Ideal qiymat 0,5")
ax.set_xlabel("Raundlar soni"); ax.set_ylabel("O‘zgargan chiqish bitlari ulushi")
ax.set_xticks(range(1, 11)); ax.legend(fontsize=8)
rasm_saqla(fig, "bob07", "kochki")
jadval_yoz("bob07", "kochki_aes", ["Raund"] + list(range(1, 11)),
           [["O‘zgargan bitlar, %"] + [f"{v * 100:.1f}".replace(".", ",") for v in aes_nat]])

# ------------------------------------------------ 3. ECB va CTR (rangli tasvir)
W, H = 384, 192
img = Image.new("RGB", (W, H), (230, 238, 245))
dr = ImageDraw.Draw(img)
dr.rectangle([20, 20, 120, 170], fill=(31, 92, 153))       # ko'k to'rtburchak
dr.ellipse([140, 30, 260, 150], fill=(46, 139, 87))        # yashil doira
try:
    shrift = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 70)
except OSError:
    shrift = ImageFont.load_default()
dr.text((275, 55), "K", fill=(192, 57, 43), font=shrift)   # qizil harf
dr.text((60, 118), "TATU", fill=(255, 255, 255),
        font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 44))
data = np.array(img).tobytes()
k = secrets.token_bytes(16)
# RGB baytlarini blok chegarasigacha to'ldirib shifrlash
pad = (-len(data)) % 16
dd = data + b"\x00" * pad
ecb = Cipher(algorithms.AES(k), modes.ECB()).encryptor().update(dd)[:len(data)]
ctr = Cipher(algorithms.AES(k), modes.CTR(secrets.token_bytes(16))).encryptor().update(data)
fig, axs = plt.subplots(1, 3, figsize=(10, 2.4))
for a, d, t in zip(axs, (data, ecb, ctr), ("Ochiq tasvir", "AES-ECB shifrmatni", "AES-CTR shifrmatni")):
    a.imshow(np.frombuffer(d, dtype=np.uint8).reshape(H, W, 3))
    a.set_title(t, fontsize=12); a.axis("off")
rasm_saqla(fig, "bob07", "ecb_tasvir")

# ------------------------------------------------ 4. tezlik
buf = secrets.token_bytes(16 * 2 ** 20)


def _vaqt(obj):
    t0 = time.perf_counter(); obj.encrypt(os.urandom(12), buf, None)
    return time.perf_counter() - t0


natija = []
for nom, obj in (("AES-128-GCM", AESGCM(AESGCM.generate_key(128))), ("AES-256-GCM", AESGCM(AESGCM.generate_key(256))),
                 ("ChaCha20-Poly1305", ChaCha20Poly1305(ChaCha20Poly1305.generate_key()))):
    obj.encrypt(os.urandom(12), buf, None)                     # "qizdirish"
    t = min(_vaqt(obj) for _ in range(5))
    natija.append([nom, "OpenSSL (cryptography kutubxonasi)", f"{len(buf) / t / 2 ** 20:,.0f}".replace(",", " ")])
t0 = time.perf_counter()
for _ in range(200):
    aes_shifrla(bytes(16), bytes(16))
t = time.perf_counter() - t0
natija.append(["AES-128 (ECB)", "Ushbu qo‘llanmadagi sof Python realizatsiyasi", f"{200 * 16 / t / 2 ** 20:.4f}".replace(".", ",")])
jadval_yoz("bob07", "tezlik", ["Algoritm", "Realizatsiya", "Tezlik, MB/s"], natija)
