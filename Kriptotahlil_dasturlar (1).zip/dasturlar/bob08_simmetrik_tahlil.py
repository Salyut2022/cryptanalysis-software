# -*- coding: utf-8 -*-
"""8-bob: simmetrik shifrlash algoritmlarining kriptotahlil usullari (o'quv SP-tarmog'i misolida).
  1) S-bloklarning chiziqli approksimatsiyalar jadvali (LAT) va farqlar taqsimoti jadvali (DDT);
  2) chiziqli kriptotahlil: oxirgi raund kalitining 8 bitini tiklash (Matsui 2-algoritmi);
  3) differensial kriptotahlil: oxirgi raund kalitining 8 bitini tiklash;
  4) integral kriptotahlil: 3 raundli "nol yig'indi" xossasi va 4-raund kalitini tiklash;
  5) algebraik tahlil: S-bloklarni ifodalovchi kvadratik tenglamalar soni."""
import random
from functools import reduce
from itertools import combinations
import numpy as np
import matplotlib.pyplot as plt
from shifrlar import (SPN_S, SPN_SI, spn_shifrla, AES_S, PRESENT_S, TDES_SL, des_sbox_jadval)
from umumiy import rasm_saqla, jadval_yoz, matn_yoz

random.seed(8)


def lat(S, n, m):
    return np.array([[sum((bin(a & x).count("1") + bin(b & S[x]).count("1")) % 2 == 0 for x in range(2 ** n)) - 2 ** (n - 1)
                      for b in range(2 ** m)] for a in range(2 ** n)])


def ddt(S, n, m):
    T = np.zeros((2 ** n, 2 ** m), dtype=int)
    for a in range(2 ** n):
        for x in range(2 ** n):
            T[a, S[x] ^ S[x ^ a]] += 1
    return T


L, D = lat(SPN_S, 4, 4), ddt(SPN_S, 4, 4)
fig, axs = plt.subplots(1, 2, figsize=(9.5, 4.2))
for ax, M, t in ((axs[0], L, "LAT: #{a·x = b·S(x)} − 8"), (axs[1], D, "DDT: #{S(x) ⊕ S(x ⊕ Δx) = Δy}")):
    im = ax.imshow(M, cmap="RdBu_r" if M is L else "Blues", vmin=-8 if M is L else 0, vmax=8 if M is L else 16)
    for i in range(16):
        for j in range(16):
            if M[i, j]:
                ax.text(j, i, str(M[i, j]), ha="center", va="center", fontsize=6)
    ax.set_xticks(range(16)); ax.set_yticks(range(16))
    ax.set_xticklabels([f"{i:X}" for i in range(16)], fontsize=7); ax.set_yticklabels([f"{i:X}" for i in range(16)], fontsize=7)
    ax.set_title(t, fontsize=9); ax.grid(False)
axs[0].set_xlabel("Chiqish niqobi b"); axs[0].set_ylabel("Kirish niqobi a")
axs[1].set_xlabel("Chiqish farqi Δy"); axs[1].set_ylabel("Kirish farqi Δx")
rasm_saqla(fig, "bob08", "lat_ddt")
Lt = lat(des_sbox_jadval(TDES_SL), 6, 4)
matn_yoz("bob08", "lat_tdes", f"TDES chap S-bloki: LAT[a=001100, b=0110] = {Lt[12, 6]} (64 tadan {32 + Lt[12, 6]} holatda bajariladi);"
         f" LAT[a=001000, b=0100] = {Lt[8, 4]}")

# raund kalitlari
K = [random.randrange(1 << 16) for _ in range(5)]


def nibl(x, i):  # i = 1..4, chapdan sanaladi
    return (x >> (4 * (4 - i))) & 0xF


def bit(x, i):  # i = 1..16, chapdan sanaladi
    return (x >> (16 - i)) & 1


# ------------------------------------------------ 2. chiziqli kriptotahlil
T = 10000
juftlar = [(p, spn_shifrla(p, K)) for p in (random.randrange(1 << 16) for _ in range(T))]
siljish = []
for k in range(256):
    k2, k4 = k >> 4, k & 15
    sanoq = 0
    for p, c in juftlar:
        u2, u4 = SPN_SI[nibl(c, 2) ^ k2], SPN_SI[nibl(c, 4) ^ k4]
        # U4,6 ⊕ U4,8 ⊕ U4,14 ⊕ U4,16 ⊕ P5 ⊕ P7 ⊕ P8 = 0
        v = ((u2 >> 2) & 1) ^ (u2 & 1) ^ ((u4 >> 2) & 1) ^ (u4 & 1) ^ bit(p, 5) ^ bit(p, 7) ^ bit(p, 8)
        sanoq += (v == 0)
    siljish.append(abs(sanoq / T - 0.5))
haq = (nibl(K[4], 2) << 4) | nibl(K[4], 4)
eng = sorted(range(256), key=lambda k: -siljish[k])
fig, ax = plt.subplots(figsize=(7.5, 3.2))
ax.bar(range(256), siljish, width=1.0, color="#1f5c99")
ax.bar([haq], [siljish[haq]], width=3, color="#c0392b", label=f"Haqiqiy qism kalit {haq:02X}")
ax.axhline(1 / 32, color="k", ls="--", lw=1, label="Nazariy siljish 1/32")
ax.set_xlabel("Qism kalit nomzodi [K5,5…8 | K5,13…16]"); ax.set_ylabel("|siljish|"); ax.legend(fontsize=8)
rasm_saqla(fig, "bob08", "chiziqli_hujum")
jadval_yoz("bob08", "chiziqli_hujum", ["O‘rin", "Qism kalit (16-lik)", "|siljish|"],
           [[i + 1, f"{k:02X}" + (" (haqiqiy)" if k == haq else ""), f"{siljish[k]:.4f}".replace(".", ",")] for i, k in enumerate(eng[:5])])

# ------------------------------------------------ 3. differensial kriptotahlil
DP = 0x0B00
NP = 5000
hisob = np.zeros(256, dtype=int); filtr = 0
for _ in range(NP):
    p = random.randrange(1 << 16)
    c1, c2 = spn_shifrla(p, K), spn_shifrla(p ^ DP, K)
    if nibl(c1 ^ c2, 1) or nibl(c1 ^ c2, 3):
        continue                                   # to'g'ri juftlik bo'lishi mumkin emas
    filtr += 1
    for k in range(256):
        k2, k4 = k >> 4, k & 15
        if (SPN_SI[nibl(c1, 2) ^ k2] ^ SPN_SI[nibl(c2, 2) ^ k2]) == 6 and \
           (SPN_SI[nibl(c1, 4) ^ k4] ^ SPN_SI[nibl(c2, 4) ^ k4]) == 6:
            hisob[k] += 1
eng = np.argsort(-hisob)
fig, ax = plt.subplots(figsize=(7.5, 3.2))
ax.bar(range(256), hisob / NP, width=1.0, color="#1f5c99")
ax.bar([haq], [hisob[haq] / NP], width=3, color="#c0392b", label=f"Haqiqiy qism kalit {haq:02X}")
ax.axhline(27 / 1024, color="k", ls="--", lw=1, label="Nazariy ehtimollik 27/1024")
ax.set_xlabel("Qism kalit nomzodi [K5,5…8 | K5,13…16]"); ax.set_ylabel("To‘g‘ri juftliklar ulushi"); ax.legend(fontsize=8)
rasm_saqla(fig, "bob08", "diff_hujum")
jadval_yoz("bob08", "diff_hujum", ["O‘rin", "Qism kalit (16-lik)", "Sanoq", "Ehtimollik"],
           [[i + 1, f"{k:02X}" + (" (haqiqiy)" if k == haq else ""), hisob[k], f"{hisob[k] / NP:.4f}".replace(".", ",")] for i, k in enumerate(eng[:5])])
matn_yoz("bob08", "diff_filtr", f"{NP} ta tanlangan juftlikdan filtrdan o‘tgani: {filtr}")


# ------------------------------------------------ 4. integral kriptotahlil
def toplam(faol, konst):
    sh = 4 * (4 - faol)
    return [(konst & ~(0xF << sh)) | (v << sh) for v in range(16)]


qatorlar = []
nomzod = [set(range(16)) for _ in range(4)]
tanlangan = 0
for t in range(3):
    matnlar = toplam(1, random.randrange(65536)); tanlangan += 16
    cs = [spn_shifrla(p, K) for p in matnlar]
    for i in range(1, 5):
        nomzod[i - 1] = {k for k in nomzod[i - 1] if
                         reduce(lambda a, b: a ^ b, [SPN_SI[nibl(c, i) ^ k] for c in cs]) == 0}
    qatorlar.append([t + 1, tanlangan] + [len(s) for s in nomzod])
jadval_yoz("bob08", "integral", ["To‘plam", "Tanlangan matnlar", "K5 1-nibl nomzodlari", "2-nibl", "3-nibl", "4-nibl"], qatorlar)
topildi = "".join(f"{min(s):X}" if len(s) == 1 else "?" for s in nomzod)
matn_yoz("bob08", "integral_natija", f"Tiklangan K5 = {topildi}, haqiqiy K5 = {K[4]:04X}")


# ------------------------------------------------ 5. algebraik tahlil: kvadratik tenglamalar soni
def kvadratik_tenglamalar(S, n):
    o = [((x >> (n - 1 - i)) & 1) for x in range(2 ** n) for i in range(n)]
    satrlar = []
    for x in range(2 ** n):
        v = [(x >> (n - 1 - i)) & 1 for i in range(n)] + [(S[x] >> (n - 1 - i)) & 1 for i in range(n)]
        satrlar.append([1] + v + [v[i] & v[j] for i, j in combinations(range(2 * n), 2)])
    M = np.array(satrlar, dtype=np.uint8) % 2
    # GF(2) dagi rang
    M = M.copy(); r = 0
    for c in range(M.shape[1]):
        piv = next((i for i in range(r, M.shape[0]) if M[i, c]), None)
        if piv is None:
            continue
        M[[r, piv]] = M[[piv, r]]
        for i in range(M.shape[0]):
            if i != r and M[i, c]:
                M[i] ^= M[r]
        r += 1
    return M.shape[1], r, M.shape[1] - r


qatorlar = []
for nom, S, n in (("O‘quv SPN (4 bit)", SPN_S, 4), ("PRESENT (4 bit)", PRESENT_S, 4), ("AES (8 bit)", AES_S, 8)):
    mon, rang, teng = kvadratik_tenglamalar(S, n)
    qatorlar.append([nom, 2 * n, mon, rang, teng])
jadval_yoz("bob08", "algebraik", ["S-blok", "O‘zgaruvchilar (x, y)", "Darajasi ≤ 2 bo‘lgan monomlar", "Matritsa rangi", "Chiziqli erkli kvadratik tenglamalar"], qatorlar)
