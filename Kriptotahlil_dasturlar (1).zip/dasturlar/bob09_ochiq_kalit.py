# -*- coding: utf-8 -*-
"""9-bob: ochiq kalitli shifrlarning kriptotahlili.
  1) faktorlash algoritmlari (sinov bo'lish, Pollard rho, Pollard p−1) ish vaqti;
  2) RSA ga hujumlar: Ferma usuli (yaqin tub sonlar), Viner hujumi (kichik d),
     Hostad hujumi (kichik e, bir xabar uch qabul qiluvchiga), umumiy tub ko'paytuvchi (EKUB);
  3) diskret logarifm: "kichik qadam - katta qadam", Pollard rho, Pohlig-Hellman;
  4) ECDSA da bir martalik son (nonce) takrorlanganda maxfiy kalitni tiklash (secp256k1)."""
import math
import random
import time
import hashlib
import matplotlib.pyplot as plt
from sympy import randprime, nextprime, isprime, integer_nthroot, factorint
from umumiy import rasm_saqla, jadval_yoz, matn_yoz

random.seed(9)


# ------------------------------------------------ 1. faktorlash
def sinov_bolish(n):
    if n % 2 == 0:
        return 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return d
        d += 2
    return n


def pollard_rho(n):
    if n % 2 == 0:
        return 2
    c = 1
    while True:
        x = y = 2; d = 1
        while d == 1:
            x = (x * x + c) % n; y = (y * y + c) % n; y = (y * y + c) % n
            d = math.gcd(abs(x - y), n)
        if d != n:
            return d
        c += 1


def pollard_p1(n, B=100000):
    a = 2
    for p in range(2, B):
        if isprime(p):
            a = pow(a, p ** int(math.log(B, p)), n)
            if p % 1000 == 3:
                d = math.gcd(a - 1, n)
                if 1 < d < n:
                    return d
    d = math.gcd(a - 1, n)
    return d if 1 < d < n else None


def olchov(f, n, takror=3):
    t0 = time.perf_counter()
    for _ in range(takror):
        f(n)
    return (time.perf_counter() - t0) / takror


bitlar, t_sinov, t_rho = list(range(24, 69, 4)), [], []
for b in bitlar:
    n = randprime(2 ** (b // 2 - 1), 2 ** (b // 2)) * randprime(2 ** (b // 2 - 1), 2 ** (b // 2))
    t_sinov.append(olchov(sinov_bolish, n, 1) if b <= 48 else float("nan"))
    t_rho.append(olchov(pollard_rho, n))
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.semilogy(bitlar, t_sinov, "o-", label=r"Sinov bo‘lish, $O(\sqrt{n})$")
ax.semilogy(bitlar, t_rho, "s-", label=r"Pollard rho, $O(n^{1/4})$")
ax.set_xlabel("n = p·q ning uzunligi, bit"); ax.set_ylabel("Vaqt, s"); ax.legend(fontsize=8)
rasm_saqla(fig, "bob09", "faktorlash_vaqt")

# p-1 usuli: p − 1 silliq bo'lgan holat
while True:
    k = 1
    for p_ in random.sample([q for q in range(3, 2000) if isprime(q)], 25):
        k *= p_
    if isprime(2 * k + 1):
        p_silliq = 2 * k + 1; break
q_katta = randprime(2 ** 255, 2 ** 256)
n_p1 = p_silliq * q_katta
t0 = time.perf_counter(); d = pollard_p1(n_p1); t_p1 = time.perf_counter() - t0

# ------------------------------------------------ 2. RSA hujumlari
# Ferma: |p − q| kichik
p = randprime(2 ** 511, 2 ** 512); q = nextprime(p + random.getrandbits(200))
n = p * q
a = math.isqrt(n) + (0 if math.isqrt(n) ** 2 == n else 1); qadam = 0
while True:
    b2 = a * a - n; b = math.isqrt(b2); qadam += 1
    if b * b == b2:
        break
    a += 1
ferma_ok = {a - b, a + b} == {p, q}


# Viner: d < n^(1/4)/3
def davomiy_kasr(x, y):
    while y:
        q_ = x // y; yield q_; x, y = y, x - q_ * y


def viner(e, n):
    h0, h1, k0, k1 = 0, 1, 1, 0
    for a_ in davomiy_kasr(e, n):
        h0, h1 = h1, a_ * h1 + h0
        k0, k1 = k1, a_ * k1 + k0
        k_, d_ = h1, k1
        if k_ == 0 or (e * d_ - 1) % k_:
            continue
        phi = (e * d_ - 1) // k_
        s = n - phi + 1; D = s * s - 4 * n
        if D >= 0 and math.isqrt(D) ** 2 == D:
            return d_
    return None


p = randprime(2 ** 511, 2 ** 512); q = randprime(2 ** 511, 2 ** 512); n = p * q; phi = (p - 1) * (q - 1)
while True:
    d_kichik = random.getrandbits(250) | 1
    if math.gcd(d_kichik, phi) == 1:
        break
e = pow(d_kichik, -1, phi)
t0 = time.perf_counter(); d_top = viner(e, n); t_viner = time.perf_counter() - t0

# Hostad: e = 3, bitta xabar uch xil modul bilan shifrlangan
xabar = int.from_bytes(b"Uchrashuv soat 14:00 da, 3-xonada", "big")
modullar = [randprime(2 ** 511, 2 ** 512) * randprime(2 ** 511, 2 ** 512) for _ in range(3)]
cs = [pow(xabar, 3, N) for N in modullar]
N = math.prod(modullar)
x = sum(c * (N // Ni) * pow(N // Ni, -1, Ni) for c, Ni in zip(cs, modullar)) % N
ildiz, aniq = integer_nthroot(x, 3)
hostad = ildiz.to_bytes((ildiz.bit_length() + 7) // 8, "big").decode()

# Umumiy tub ko'paytuvchi: kalitlar to'plamida EKUB
tublar = [randprime(2 ** 255, 2 ** 256) for _ in range(40)]
kalitlar = [tublar[2 * i] * tublar[2 * i + 1] for i in range(20)]
kalitlar[13] = tublar[6] * randprime(2 ** 255, 2 ** 256)        # zaif generator: tub son takrorlangan
topilgan = [(i, j) for i in range(20) for j in range(i + 1, 20) if math.gcd(kalitlar[i], kalitlar[j]) > 1]

jadval_yoz("bob09", "rsa_hujumlar", ["Hujum", "Shart", "Natija"],
           [["Ferma usuli", "1024 bitli n, |p − q| < 2²⁰⁰", f"{qadam} qadamda faktorlandi: {'ha' if ferma_ok else 'yo‘q'}"],
            ["Pollard p − 1", f"{n_p1.bit_length()} bitli n, p − 1 silliq", f"p topildi: {'ha' if d == p_silliq else 'yo‘q'}, {t_p1:.2f} s".replace(".", ",")],
            ["Viner hujumi", "1024 bitli n, d ≈ 2²⁵⁰ < n^{1/4}/3", f"d tiklandi: {'ha' if d_top == d_kichik else 'yo‘q'}, {t_viner * 1000:.1f} ms".replace(".", ",")],
            ["Hostad hujumi", "e = 3, uch xil 1024 bitli modul", f"xabar: «{hostad}»"],
            ["Umumiy EKUB", "20 ta 512 bitli modul, bitta tub son takrorlangan", f"zaif juftlik(lar): {topilgan}"]])


# ------------------------------------------------ 3. diskret logarifm
def kq_kq(g, h, p, n):
    m = math.isqrt(n) + 1
    jadval = {pow(g, j, p): j for j in range(m)}
    c = pow(g, -m, p); y = h
    for i in range(m):
        if y in jadval:
            return i * m + jadval[y]
        y = y * c % p
    return None


def rho_log(g, h, p, n):
    def qadam_(x, a, b):
        s = x % 3
        if s == 0:
            return x * x % p, 2 * a % n, 2 * b % n
        if s == 1:
            return x * g % p, (a + 1) % n, b
        return x * h % p, a, (b + 1) % n
    while True:
        a0, b0 = random.randrange(n), random.randrange(n)
        x = pow(g, a0, p) * pow(h, b0, p) % p
        X, A, B = x, a0, b0; Y, A2, B2 = x, a0, b0
        while True:
            X, A, B = qadam_(X, A, B)
            Y, A2, B2 = qadam_(*qadam_(Y, A2, B2))
            if X == Y:
                break
        r = (B - B2) % n
        if r == 0:
            continue
        d_ = math.gcd(r, n)
        for t in range(d_):
            x_ = (((A2 - A) // d_ * pow(r // d_, -1, n // d_)) + t * n // d_) % n if (A2 - A) % d_ == 0 else None
            if x_ is not None and pow(g, x_, p) == h:
                return x_


def xavfsiz_tub(b):
    while True:
        q_ = randprime(2 ** (b - 2), 2 ** (b - 1))
        if isprime(2 * q_ + 1):
            return 2 * q_ + 1, q_


bit2, t_bsgs, t_rhol = list(range(20, 49, 4)), [], []
for b in bit2:
    p, q_ = xavfsiz_tub(b)
    g = 4                                    # q tartibli qism guruh generatori
    x = random.randrange(q_); h = pow(g, x, p)
    t0 = time.perf_counter(); assert kq_kq(g, h, p, q_) == x; t_bsgs.append(time.perf_counter() - t0)
    t0 = time.perf_counter(); assert rho_log(g, h, p, q_) == x; t_rhol.append(time.perf_counter() - t0)
fig, ax = plt.subplots(figsize=(7, 3.6))
ax.semilogy(bit2, t_bsgs, "o-", label="Kichik qadam – katta qadam (xotira O(√q))")
ax.semilogy(bit2, t_rhol, "s-", label="Pollard rho (xotira O(1))")
ax.semilogy(bit2, [t_bsgs[0] * 2 ** ((b - bit2[0]) / 2) for b in bit2], "k:", label="√q ga proporsional o‘sish")
ax.set_xlabel("Guruh tartibi q ning uzunligi, bit"); ax.set_ylabel("Vaqt, s"); ax.legend(fontsize=8)
rasm_saqla(fig, "bob09", "dlog_vaqt")


def pohlig_hellman(g, h, p):
    n = p - 1; f = factorint(n); qoldiq, modul = 0, 1
    for q_, e_ in f.items():
        x_ = 0; gq = pow(g, n // q_, p)
        for k in range(e_):
            hk = pow(h * pow(g, -x_, p) % p, n // q_ ** (k + 1), p)
            dk = kq_kq(gq, hk, p, q_)
            x_ += dk * q_ ** k
        m_ = q_ ** e_
        qoldiq = (qoldiq * m_ * pow(m_, -1, modul) + x_ * modul * pow(modul, -1, m_)) % (modul * m_) if modul > 1 else x_
        modul *= m_
    return qoldiq


while True:
    k = 2
    for _ in range(12):
        k *= randprime(2 ** 10, 2 ** 12)
    if isprime(k + 1) and k.bit_length() > 120:
        p_ph = k + 1; break
g = next(gg for gg in range(2, 100) if all(pow(gg, (p_ph - 1) // q_, p_ph) != 1 for q_ in factorint(p_ph - 1)))
x = random.randrange(p_ph - 1); h = pow(g, x, p_ph)
t0 = time.perf_counter(); x_ph = pohlig_hellman(g, h, p_ph); t_ph = time.perf_counter() - t0
matn_yoz("bob09", "pohlig", f"p = {p_ph} ({p_ph.bit_length()} bit), p−1 = " +
         " · ".join(f"{q_}" + (f"^{e_}" if e_ > 1 else "") for q_, e_ in sorted(factorint(p_ph - 1).items())) +
         f"\nx tiklandi: {x_ph == x}, vaqt {t_ph:.3f} s")

# ------------------------------------------------ 4. ECDSA: nonce takrorlanishi (secp256k1)
P_ = 2 ** 256 - 2 ** 32 - 977
N_ = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
G = (0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798,
     0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8)


def qosh(A, B):
    if A is None:
        return B
    if B is None:
        return A
    if A[0] == B[0] and (A[1] + B[1]) % P_ == 0:
        return None
    if A == B:
        l = 3 * A[0] * A[0] * pow(2 * A[1], -1, P_) % P_
    else:
        l = (B[1] - A[1]) * pow(B[0] - A[0], -1, P_) % P_
    x3 = (l * l - A[0] - B[0]) % P_
    return x3, (l * (A[0] - x3) - A[1]) % P_


def kop(k, A):
    R = None
    while k:
        if k & 1:
            R = qosh(R, A)
        A = qosh(A, A); k >>= 1
    return R


assert (G[1] ** 2 - G[0] ** 3 - 7) % P_ == 0 and kop(N_, G) is None   # parametrlar tekshiruvi
d_sir = random.randrange(1, N_)
Q = kop(d_sir, G)


def imzo(xabar, k):
    z = int.from_bytes(hashlib.sha256(xabar).digest(), "big") % N_
    r = kop(k, G)[0] % N_
    return z, r, pow(k, -1, N_) * (z + r * d_sir) % N_


k_takror = random.randrange(1, N_)
z1, r1, s1 = imzo(b"1-hujjat: 100 so'm o'tkazish", k_takror)
z2, r2, s2 = imzo(b"2-hujjat: shartnoma", k_takror)
k_top = (z1 - z2) * pow(s1 - s2, -1, N_) % N_
d_top = (s1 * k_top - z1) * pow(r1, -1, N_) % N_
jadval_yoz("bob09", "ecdsa_nonce", ["Ko‘rsatkich", "Qiymat (16-lik, boshi)"],
           [["Ikkala imzodagi r (bir xil!)", f"{r1:064x}"[:24] + "…"],
            ["k = (z₁ − z₂)/(s₁ − s₂) mod n", f"{k_top:064x}"[:24] + "…"],
            ["d = (s₁k − z₁)/r mod n", f"{d_top:064x}"[:24] + "…"],
            ["Tiklangan d haqiqiysiga tengmi", "ha" if d_top == d_sir else "yo‘q"]])
