# -*- coding: utf-8 -*-
"""10-bob: xesh-funksiyalarning kriptotahlili.
  1) qisqartirilgan SHA-256 uchun tug'ilgan kun hujumi (kolliziya) va birlamchi obraz qidirish;
  2) Floyd usuli asosida xotirasiz kolliziya qidirish;
  3) SHA-256 ning ko'chki effekti;
  4) Merkl-Damgor qurilmasidagi uzunlikni kengaytirish hujumi (SHA-256, sir || xabar MAC)."""
import hashlib
import math
import os
import random
import struct
import time
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import binom
from umumiy import rasm_saqla, jadval_yoz, matn_yoz

random.seed(10)


def h_n(m, n):
    """SHA-256 qiymatining birinchi n biti."""
    return int.from_bytes(hashlib.sha256(m).digest(), "big") >> (256 - n)


# ------------------------------------------------ 1. kolliziya va birlamchi obraz
def kolliziya_qadam(n):
    korilgan, i = {}, 0
    tuz = os.urandom(8)
    while True:
        i += 1
        v = h_n(tuz + i.to_bytes(8, "big"), n)
        if v in korilgan:
            return i
        korilgan[v] = i


def obraz_qadam(n):
    nishon = random.getrandbits(n); i = 0; tuz = os.urandom(8)
    while True:
        i += 1
        if h_n(tuz + i.to_bytes(8, "big"), n) == nishon:
            return i


n_kol = list(range(12, 37, 4)); kol = []
for n in n_kol:
    takror = 40 if n <= 28 else 8
    kol.append(np.mean([kolliziya_qadam(n) for _ in range(takror)]))
n_obr = list(range(8, 21, 2)); obr = []
for n in n_obr:
    takror = 30 if n <= 16 else 6
    obr.append(np.mean([obraz_qadam(n) for _ in range(takror)]))
fig, ax = plt.subplots(figsize=(7, 3.8))
ax.plot(n_kol, np.log2(kol), "o", label="Kolliziya: tajriba")
ax.plot(n_kol, [math.log2(math.sqrt(math.pi * 2 ** n / 2)) for n in n_kol], "-", label="√(π·2ⁿ/2) nazariy")
ax.plot(n_obr, np.log2(obr), "s", label="Birlamchi obraz: tajriba")
ax.plot(n_obr, n_obr, "--", label="2ⁿ nazariy")
ax.set_xlabel("Xesh qiymat uzunligi n, bit"); ax.set_ylabel("log₂(urinishlar soni)"); ax.legend(fontsize=8)
rasm_saqla(fig, "bob10", "kolliziya_obraz")
jadval_yoz("bob10", "kolliziya", ["n, bit", "O‘rtacha urinishlar (tajriba)", "√(π·2ⁿ/2)", "Nisbat"],
           [[n, f"{k:,.0f}".replace(",", " "), f"{math.sqrt(math.pi * 2 ** n / 2):,.0f}".replace(",", " "),
             f"{k / math.sqrt(math.pi * 2 ** n / 2):.2f}".replace(".", ",")] for n, k in zip(n_kol, kol)])

# ------------------------------------------------ 2. Floyd usuli bilan 40 bitli kolliziya
N_BIT = 40


def f(x):  # 5 baytli qiymatni 5 baytli qiymatga akslantiradi
    return hashlib.sha256(b"TATU:" + x).digest()[:5]


t0 = time.time()
x0 = os.urandom(5)
t, h = f(x0), f(f(x0)); qadam = 1
while t != h:
    t, h = f(t), f(f(h)); qadam += 1
t = x0                                           # sikl boshini topish
while f(t) != f(h):
    t, h = f(t), f(h)
vaqt = time.time() - t0
matn_yoz("bob10", "floyd_kolliziya",
         f"m1 = 'TATU:' + {t.hex()}\nm2 = 'TATU:' + {h.hex()}\n"
         f"SHA-256(m1)[:40 bit] = {f(t).hex()} = SHA-256(m2)[:40 bit] = {f(h).hex()}\n"
         f"Floyd qadamlari: {qadam:,}".replace(",", " ") + f" (2^20 ≈ 1 048 576); vaqt {vaqt:.1f} s".replace(".", ",")
         + "; qo‘shimcha xotira: 3 ta 40 bitli qiymat")

# ------------------------------------------------ 3. ko'chki effekti
SON = 20000
masofa = []
for _ in range(SON):
    m = bytearray(os.urandom(32)); a = hashlib.sha256(m).digest()
    b = random.randrange(256); m[b // 8] ^= 1 << (b % 8)
    masofa.append(sum(bin(x ^ y).count("1") for x, y in zip(a, hashlib.sha256(m).digest())))
fig, ax = plt.subplots(figsize=(7, 3.4))
ax.hist(masofa, bins=range(90, 168), density=True, color="#1f5c99", label="SHA-256 (tajriba)")
k = np.arange(90, 168)
ax.plot(k, binom.pmf(k, 256, 0.5), "r-", lw=1.5, label="Binomial taqsimot B(256; 0,5)")
ax.set_xlabel("Bitta kirish biti o‘zgarganda o‘zgargan chiqish bitlari soni"); ax.set_ylabel("Ehtimollik")
ax.set_title(f"O‘rtacha {np.mean(masofa):.2f} bit, standart chetlanish {np.std(masofa):.2f} (nazariy 128 va 8)".replace(".", ","), fontsize=9)
ax.legend(fontsize=8)
rasm_saqla(fig, "bob10", "sha256_kochki")

# ------------------------------------------------ 4. uzunlikni kengaytirish hujumi
K_ = [int(x, 16) for x in """428a2f98 71374491 b5c0fbcf e9b5dba5 3956c25b 59f111f1 923f82a4 ab1c5ed5 d807aa98 12835b01
243185be 550c7dc3 72be5d74 80deb1fe 9bdc06a7 c19bf174 e49b69c1 efbe4786 0fc19dc6 240ca1cc 2de92c6f 4a7484aa 5cb0a9dc
76f988da 983e5152 a831c66d b00327c8 bf597fc7 c6e00bf3 d5a79147 06ca6351 14292967 27b70a85 2e1b2138 4d2c6dfc 53380d13
650a7354 766a0abb 81c2c92e 92722c85 a2bfe8a1 a81a664b c24b8b70 c76c51a3 d192e819 d6990624 f40e3585 106aa070 19a4c116
1e376c08 2748774c 34b0bcb5 391c0cb3 4ed8aa4a 5b9cca4f 682e6ff3 748f82ee 78a5636f 84c87814 8cc70208 90befffa a4506ceb
bef9a3f7 c67178f2""".split()]
H0 = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]
M32 = 0xFFFFFFFF


def ror(x, r):
    return ((x >> r) | (x << (32 - r))) & M32


def siqish(H, blok):
    w = list(struct.unpack(">16I", blok))
    for i in range(16, 64):
        s0 = ror(w[i - 15], 7) ^ ror(w[i - 15], 18) ^ (w[i - 15] >> 3)
        s1 = ror(w[i - 2], 17) ^ ror(w[i - 2], 19) ^ (w[i - 2] >> 10)
        w.append((w[i - 16] + s0 + w[i - 7] + s1) & M32)
    a, b, c, d, e, f_, g, h = H
    for i in range(64):
        t1 = (h + (ror(e, 6) ^ ror(e, 11) ^ ror(e, 25)) + ((e & f_) ^ (~e & g)) + K_[i] + w[i]) & M32
        t2 = ((ror(a, 2) ^ ror(a, 13) ^ ror(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) & M32
        a, b, c, d, e, f_, g, h = (t1 + t2) & M32, a, b, c, (d + t1) & M32, e, f_, g
    return [(x + y) & M32 for x, y in zip(H, [a, b, c, d, e, f_, g, h])]


def toldirish(uzunlik):
    return b"\x80" + b"\x00" * ((55 - uzunlik) % 64) + struct.pack(">Q", 8 * uzunlik)


def sha256(m, H=H0, oldingi=0):
    d = m + toldirish(oldingi + len(m))
    for i in range(0, len(d), 64):
        H = siqish(H, d[i:i + 64])
    return b"".join(struct.pack(">I", x) for x in H)


assert sha256(b"abc") == hashlib.sha256(b"abc").digest()
SIR = os.urandom(16)                                   # serverning maxfiy kaliti (hujumchiga noma'lum)
xabar = b"foydalanuvchi=ali&rol=talaba"
mac = hashlib.sha256(SIR + xabar).digest()             # zaif MAC: H(sir || xabar)
qoshimcha = b"&rol=admin"
L_sir = 16                                             # hujumchi sir uzunligini taxmin qiladi (odatda sinab ko'radi)
soxta_xabar = xabar + toldirish(L_sir + len(xabar)) + qoshimcha
holat = list(struct.unpack(">8I", mac))
soxta_mac = sha256(qoshimcha, holat, L_sir + len(xabar) + len(toldirish(L_sir + len(xabar))))
togri = hashlib.sha256(SIR + soxta_xabar).digest() == soxta_mac
jadval_yoz("bob10", "uzunlik_kengaytirish", ["Ko‘rsatkich", "Qiymat"],
           [["Asl xabar", xabar.decode()], ["Asl MAC (boshi)", mac.hex()[:32] + "…"],
            ["Soxta xabar", "asl xabar + to‘ldirish baytlari + «&rol=admin»"],
            ["Soxta xabar uzunligi, bayt", len(soxta_xabar)], ["Soxta MAC (boshi)", soxta_mac.hex()[:32] + "…"],
            ["Server tekshiruvidan o‘tdimi", "ha" if togri else "yo‘q"]])
