# -*- coding: utf-8 -*-
"""11-bob: kriptotahlilda yangi texnologiyalardan foydalanish.
  1) mashinali o'qitishga asoslangan differensial farqlovchi (o'quv SP-tarmog'i, Gohr g'oyasi asosida);
  2) parallel hisoblashda Amdal qonuni;
  3) Grover algoritmining holatlar vektori orqali simulyatsiyasi;
  4) Shor algoritmidagi faktorlashni tartib topishga keltirish (klassik simulyatsiya)."""
import math
import random
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPClassifier
from shifrlar import spn_shifrla
from umumiy import rasm_saqla, jadval_yoz

random.seed(11)
np.random.seed(11)


# ------------------------------------------------ 1. neyron tarmoqli farqlovchi
def bitlar16(x):
    return [(x >> (15 - i)) & 1 for i in range(16)]


def malumot(son, raund, delta=0x0B00):
    X, y = [], []
    for _ in range(son):
        ks = [random.randrange(65536) for _ in range(raund + 1)]
        p = random.randrange(65536)
        if random.random() < 0.5:
            c1, c2, t = spn_shifrla(p, ks, raund), spn_shifrla(p ^ delta, ks, raund), 1
        else:
            c1, c2, t = spn_shifrla(p, ks, raund), random.randrange(65536), 0
        X.append(bitlar16(c1) + bitlar16(c2) + bitlar16(c1 ^ c2)); y.append(t)
    return np.array(X), np.array(y)


qatorlar = []
for r in (1, 2, 3, 4):
    Xo, yo = malumot(30000, r); Xt, yt = malumot(10000, r)
    model = MLPClassifier(hidden_layer_sizes=(64, 64), max_iter=60, random_state=1, early_stopping=True)
    model.fit(Xo, yo)
    aniq = model.score(Xt, yt)
    qatorlar.append([r, "30 000 / 10 000", f"{aniq * 100:.1f}".replace(".", ","),
                     "farqlay oladi" if aniq > 0.52 else "tasodifiydan farqlay olmaydi"])
jadval_yoz("bob11", "neyron_farqlovchi", ["Raundlar soni", "O‘qitish / test namunalari", "Test aniqligi, %", "Xulosa"], qatorlar)

# ------------------------------------------------ 2. Amdal qonuni
P = np.logspace(0, 4, 200)
fig, ax = plt.subplots(figsize=(7, 3.6))
for f in (0.5, 0.9, 0.99, 0.999, 1.0):
    ax.loglog(P, 1 / ((1 - f) + f / P), label=f"parallel qism f = {f}".replace(".", ","))
ax.set_xlabel("Hisoblash qurilmalari soni P"); ax.set_ylabel("Tezlashish S(P)"); ax.legend(fontsize=8)
rasm_saqla(fig, "bob11", "amdal")

# ------------------------------------------------ 3. Grover algoritmi
n = 10; N = 2 ** n; nishon = 637
psi = np.full(N, 1 / math.sqrt(N))
ehtimol = [psi[nishon] ** 2]
for _ in range(60):
    psi[nishon] *= -1                              # orakul: nishon amplitudasining ishorasini o'zgartiradi
    psi = 2 * psi.mean() - psi                     # diffuziya: o'rtacha qiymatga nisbatan aks ettirish
    ehtimol.append(psi[nishon] ** 2)
opt = round(math.pi / 4 * math.sqrt(N))
fig, ax = plt.subplots(figsize=(7, 3.4))
ax.plot(range(61), ehtimol, ".-")
ax.axvline(opt, color="#c0392b", ls="--", label=f"⌊π/4·√N⌉ = {opt}")
ax.set_xlabel("Grover iteratsiyalari soni"); ax.set_ylabel("Nishonni o‘lchash ehtimolligi")
ax.set_title(f"N = 2¹⁰ = 1024 ta element; klassik qidiruvda o‘rtacha 512 ta so‘rov kerak", fontsize=9)
ax.legend(fontsize=8)
rasm_saqla(fig, "bob11", "grover")


# ------------------------------------------------ 4. Shor: faktorlashni tartib topishga keltirish
def tartib(a, N_):
    r, x = 1, a % N_
    while x != 1:
        x = x * a % N_; r += 1
    return r


qatorlar = []
for N_ in (15, 21, 35, 91, 143, 1147):
    for a in range(2, N_):
        if math.gcd(a, N_) != 1:
            continue
        r = tartib(a, N_)
        if r % 2 == 0 and pow(a, r // 2, N_) != N_ - 1:
            p_ = math.gcd(pow(a, r // 2) - 1, N_); q_ = math.gcd(pow(a, r // 2) + 1, N_)
            qatorlar.append([N_, a, r, f"{a}^{r // 2} mod {N_} = {pow(a, r // 2, N_)}", f"{p_} · {q_}"])
            break
jadval_yoz("bob11", "shor", ["N", "a", "Tartib r", "a^{r/2} mod N", "EKUB(a^{r/2} ∓ 1, N)"], qatorlar)
