# -*- coding: utf-8 -*-
"""O'quv maqsadidagi shifrlar va S-bloklar to'plami.

  * TDES  - Tiny DES (M. Stamp): 16 bitli blok, 16 bitli kalit, 4 raundli Feystel tarmog'i;
  * SPN16 - H. Heys o'quv SP-tarmog'i: 16 bitli blok, 4 raund, 4 bitli S-bloklar;
  * AES   - AES-128 ning raundlar sonini o'zgartirish mumkin bo'lgan Python realizatsiyasi;
  * DES, AES, Magma (GOST 28147-89 / GOST R 34.12-2015), PRESENT S-bloklari.
Kodlar faqat o'quv maqsadida yozilgan, amaliy himoya uchun ishlatilmaydi.
"""

# ---------------------------------------------------------------- TDES
TDES_SL = [  # chap S-blok: satr = x0x5, ustun = x1x2x3x4
    [0x6, 0x9, 0xA, 0x3, 0x4, 0xD, 0x7, 0x8, 0xE, 0x1, 0x2, 0xB, 0x5, 0xC, 0xF, 0x0],
    [0x9, 0xE, 0xB, 0xA, 0x4, 0x5, 0x0, 0x7, 0x8, 0x6, 0x3, 0x2, 0xC, 0xD, 0x1, 0xF],
    [0x8, 0x1, 0xC, 0x2, 0xD, 0x3, 0xE, 0xF, 0x0, 0x9, 0x5, 0xA, 0x4, 0xB, 0x6, 0x7],
    [0x9, 0x0, 0x2, 0x5, 0xA, 0xD, 0x6, 0xE, 0x1, 0x8, 0xB, 0xC, 0x3, 0x4, 0x7, 0xF]]
TDES_SR = [  # o'ng S-blok
    [0xC, 0x5, 0x0, 0xA, 0xE, 0x7, 0x2, 0x8, 0xD, 0x4, 0x3, 0x9, 0x6, 0xF, 0x1, 0xB],
    [0x1, 0xC, 0x9, 0x6, 0x3, 0xE, 0xB, 0x2, 0xF, 0x8, 0x4, 0x5, 0xD, 0xA, 0x0, 0x7],
    [0xF, 0xA, 0xE, 0x6, 0xD, 0x8, 0x2, 0x4, 0x1, 0x7, 0x9, 0x0, 0x3, 0x5, 0xB, 0xC],
    [0x0, 0xA, 0x3, 0xC, 0x8, 0x2, 0x1, 0xE, 0x9, 0x7, 0xF, 0x6, 0xB, 0x5, 0xD, 0x4]]
# raund kalitlari: k0..k15 bitlarining indekslari
TDES_KS = [[2, 4, 5, 6, 7, 1, 10, 11, 12, 14, 15, 8],
           [4, 6, 7, 0, 1, 3, 11, 12, 13, 15, 8, 9],
           [6, 0, 1, 2, 3, 5, 12, 13, 14, 8, 9, 10],
           [0, 2, 3, 4, 5, 7, 13, 14, 15, 9, 10, 11]]
TDES_EXP = [4, 7, 2, 1, 5, 7, 0, 2, 6, 5, 0, 3]


def bitlar(x, n):
    """x sonining n ta bitini chapdan o'ngga (MSB birinchi) ro'yxat ko'rinishida qaytaradi."""
    return [(x >> (n - 1 - i)) & 1 for i in range(n)]


def son(b):
    r = 0
    for v in b:
        r = (r << 1) | v
    return r


def tdes_sbox6(tab, x6):
    b = bitlar(x6, 6)
    return tab[(b[0] << 1) | b[5]][son(b[1:5])]


def tdes_raund_kalitlari(k16):
    kb = bitlar(k16, 16)
    return [son([kb[i] for i in idx]) for idx in TDES_KS]


def tdes_F(r8, k12):
    rb = bitlar(r8, 8)
    e = son([rb[i] for i in TDES_EXP]) ^ k12
    return (tdes_sbox6(TDES_SL, e >> 6) << 4) | tdes_sbox6(TDES_SR, e & 0x3F)


def tdes_shifrla(p16, k16, raundlar=4):
    ks = tdes_raund_kalitlari(k16)
    L, R = p16 >> 8, p16 & 0xFF
    for i in range(raundlar):
        L, R = R, L ^ tdes_F(R, ks[i])
    return (L << 8) | R


def tdes_ochish(c16, k16, raundlar=4):
    ks = tdes_raund_kalitlari(k16)
    L, R = c16 >> 8, c16 & 0xFF
    for i in reversed(range(raundlar)):
        L, R = R ^ tdes_F(L, ks[i]), L
    return (L << 8) | R


# ---------------------------------------------------------------- SPN16 (Heys)
SPN_S = [0xE, 0x4, 0xD, 0x1, 0x2, 0xF, 0xB, 0x8, 0x3, 0xA, 0x6, 0xC, 0x5, 0x9, 0x0, 0x7]
SPN_SI = [SPN_S.index(i) for i in range(16)]
# bitlar 0..15 (0 - eng chapdagi bit); i-bit P[i] o'ringa o'tadi (4x4 matritsani transponirlash)
SPN_P = [4 * (i % 4) + i // 4 for i in range(16)]


def spn_s(x):
    return (SPN_S[x >> 12] << 12) | (SPN_S[(x >> 8) & 15] << 8) | (SPN_S[(x >> 4) & 15] << 4) | SPN_S[x & 15]


def spn_si(x):
    return (SPN_SI[x >> 12] << 12) | (SPN_SI[(x >> 8) & 15] << 8) | (SPN_SI[(x >> 4) & 15] << 4) | SPN_SI[x & 15]


def spn_p(x):
    y = 0
    for i in range(16):
        if (x >> (15 - i)) & 1:
            y |= 1 << (15 - SPN_P[i])
    return y


def spn_shifrla(p, kalitlar, raundlar=4):
    """kalitlar: raundlar+1 ta 16 bitli raund kaliti. Oxirgi raundda P qo'llanilmaydi."""
    x = p
    for r in range(raundlar - 1):
        x = spn_p(spn_s(x ^ kalitlar[r]))
    x = spn_s(x ^ kalitlar[raundlar - 1])
    return x ^ kalitlar[raundlar]


# ---------------------------------------------------------------- AES
def _gmul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a = ((a << 1) ^ 0x11B) if a & 0x80 else (a << 1)
        b >>= 1
    return r


def _aes_sbox():
    s = []
    for x in range(256):
        inv = 0
        if x:
            inv = next(y for y in range(1, 256) if _gmul(x, y) == 1)
        b, r = inv, 0x63
        for i in range(5):
            r ^= b
            b = ((b << 1) | (b >> 7)) & 0xFF
        s.append(r)
    return s


AES_S = _aes_sbox()


def aes_kalit_kengaytirish(kalit16):
    w = [list(kalit16[4 * i:4 * i + 4]) for i in range(4)]
    rcon = 1
    for i in range(4, 44):
        t = w[i - 1][:]
        if i % 4 == 0:
            t = t[1:] + t[:1]
            t = [AES_S[v] for v in t]
            t[0] ^= rcon
            rcon = _gmul(rcon, 2)
        w.append([w[i - 4][j] ^ t[j] for j in range(4)])
    return [sum(w[4 * r:4 * r + 4], []) for r in range(11)]


def _mixcol(c):
    return [_gmul(c[0], 2) ^ _gmul(c[1], 3) ^ c[2] ^ c[3],
            c[0] ^ _gmul(c[1], 2) ^ _gmul(c[2], 3) ^ c[3],
            c[0] ^ c[1] ^ _gmul(c[2], 2) ^ _gmul(c[3], 3),
            _gmul(c[0], 3) ^ c[1] ^ c[2] ^ _gmul(c[3], 2)]


def aes_shifrla(blok16, kalit16, raundlar=10, holatlar=False):
    """AES-128. raundlar<10 bo'lsa, qisqartirilgan variant (barcha raundlar to'liq).
    holatlar=True bo'lsa, har bir raunddan keyingi holat ro'yxati ham qaytariladi."""
    rk = aes_kalit_kengaytirish(kalit16)
    s = [blok16[i] ^ rk[0][i] for i in range(16)]
    tarix = []
    for r in range(1, raundlar + 1):
        s = [AES_S[v] for v in s]
        s = [s[(i + 4 * (i % 4)) % 16] for i in range(16)]  # ShiftRows (ustunlar bo'yicha joylashuv)
        if not (r == 10 and raundlar == 10):
            s = sum([_mixcol(s[4 * c:4 * c + 4]) for c in range(4)], [])
        s = [s[i] ^ rk[r][i] for i in range(16)]
        tarix.append(bytes(s))
    return (bytes(s), tarix) if holatlar else bytes(s)


# ---------------------------------------------------------------- boshqa S-bloklar
DES_S = [
    [[14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7], [0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8],
     [4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0], [15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13]],
    [[15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10], [3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5],
     [0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15], [13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9]],
    [[10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8], [13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1],
     [13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7], [1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12]],
    [[7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15], [13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9],
     [10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4], [3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14]],
    [[2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9], [14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6],
     [4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14], [11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3]],
    [[12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11], [10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8],
     [9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6], [4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13]],
    [[4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1], [13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6],
     [1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2], [6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12]],
    [[13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7], [1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2],
     [7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8], [2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11]]]

MAGMA_S = [  # GOST R 34.12-2015 (Magma) S-bloklari
    [12, 4, 6, 2, 10, 5, 11, 9, 14, 8, 13, 7, 0, 3, 15, 1],
    [6, 8, 2, 3, 9, 10, 5, 12, 1, 14, 4, 7, 11, 13, 0, 15],
    [11, 3, 5, 8, 2, 15, 10, 13, 14, 1, 7, 4, 12, 9, 6, 0],
    [12, 8, 2, 1, 13, 4, 15, 6, 7, 0, 10, 5, 3, 14, 9, 11],
    [7, 15, 5, 10, 8, 1, 6, 13, 0, 9, 3, 14, 11, 4, 2, 12],
    [5, 13, 15, 6, 9, 2, 12, 10, 11, 7, 8, 1, 4, 3, 14, 0],
    [8, 14, 2, 5, 6, 9, 1, 12, 15, 4, 11, 0, 13, 10, 3, 7],
    [1, 7, 14, 13, 0, 5, 8, 3, 4, 15, 10, 6, 9, 12, 11, 2]]

PRESENT_S = [0xC, 0x5, 0x6, 0xB, 0x9, 0x0, 0xA, 0xD, 0x3, 0xE, 0xF, 0x8, 0x4, 0x7, 0x1, 0x2]


def des_sbox_jadval(t):
    """DES uslubidagi 4x16 jadvalni 6->4 bitli funksiya (64 elementli ro'yxat) ga aylantiradi."""
    return [t[((x >> 5) << 1) | (x & 1)][(x >> 1) & 15] for x in range(64)]


if __name__ == "__main__":
    # AES ni cryptography kutubxonasi bilan tekshirish
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        k = bytes(range(16)); p = bytes.fromhex("00112233445566778899aabbccddeeff")
        e = Cipher(algorithms.AES(k), modes.ECB()).encryptor()
        print("AES tekshiruvi:", e.update(p) == aes_shifrla(p, k))
    except ImportError:
        pass
    print("FIPS-197 namunasi:", aes_shifrla(bytes.fromhex("00112233445566778899aabbccddeeff"),
                                            bytes(range(16))).hex())
    k = 0x5A3C
    print("TDES tekshiruvi:", all(tdes_ochish(tdes_shifrla(p, k), k) == p for p in range(0, 65536, 97)))
    for i, t in enumerate(DES_S):
        assert all(sorted(r) == list(range(16)) for r in t), i
    for t in MAGMA_S:
        assert sorted(t) == list(range(16))
    assert all(sorted(r) == list(range(16)) for r in TDES_SL + TDES_SR)
    print("S-bloklar tekshirildi")
