# -*- coding: utf-8 -*-
"""Umumiy yordamchi funksiyalar: rasm saqlash va jadval yozish.
Barcha boblar dasturlari shu moduldan foydalanadi."""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as _fm

ASOSIY = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(ASOSIY), "natijalar")

# Times New Roman o'rniga metrik jihatdan mos Liberation Serif ishlatiladi
_SERIF = "Liberation Serif"
for _f in _fm.fontManager.ttflist:
    if _f.name == "Times New Roman":
        _SERIF = "Times New Roman"
        break

plt.rcParams.update({
    "font.family": "serif", "font.serif": [_SERIF, "Times New Roman", "DejaVu Serif"],
    "mathtext.fontset": "stix", "font.size": 13,
    "axes.titlesize": 14, "axes.labelsize": 13,
    "xtick.labelsize": 12, "ytick.labelsize": 12, "legend.fontsize": 12,
    "axes.grid": True, "grid.alpha": 0.35, "grid.linewidth": 0.6,
    "axes.linewidth": 1.0, "axes.edgecolor": "#333333",
    "axes.prop_cycle": plt.cycler(color=["#1f5c99", "#c0392b", "#2e8b57",
                                         "#d4820a", "#6a3d9a", "#117a8b"]),
    "lines.linewidth": 2.2, "lines.markersize": 6,
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.dpi": 300, "savefig.bbox": "tight", "savefig.pad_inches": 0.18,
    "figure.autolayout": False,
})


def papka(bob):
    p = os.path.join(OUT, bob)
    os.makedirs(p, exist_ok=True)
    return p


def rasm_saqla(fig, bob, nom):
    yol = os.path.join(papka(bob), nom + ".png")
    fig.savefig(yol)
    plt.close(fig)
    print("rasm:", yol)


def jadval_yoz(bob, nom, sarlavhalar, qatorlar):
    """Markdown ko'rinishidagi jadvalni faylga yozadi va ekranga chiqaradi."""
    s = "| " + " | ".join(map(str, sarlavhalar)) + " |\n"
    s += "|" + "|".join([":---:"] * len(sarlavhalar)) + "|\n"
    for q in qatorlar:
        s += "| " + " | ".join(map(str, q)) + " |\n"
    with open(os.path.join(papka(bob), nom + ".md"), "w", encoding="utf-8") as f:
        f.write(s)
    print(s)
    return s


def matn_yoz(bob, nom, matn):
    with open(os.path.join(papka(bob), nom + ".txt"), "w", encoding="utf-8") as f:
        f.write(matn)
    print(matn)
