| Kalit uzunligi (bit) | Kalitlar soni | 10⁹ kalit/s (bitta yadro) | 10¹² kalit/s (GPU klasteri) | 10¹⁸ kalit/s (gipotetik superkompyuter) |
|:---:|:---:|:---:|:---:|:---:|
| 40 | 1,10·10¹² | 9,16 daqiqa | 0,55 s | < 1 ms |
| 56 | 7,21·10¹⁶ | 1,14 yil | 10 soat | 0,036 s |
| 64 | 1,84·10¹⁹ | 292 yil | 107 kun | 9,22 s |
| 80 | 1,21·10²⁴ | 10⁷ yil | 19 154 yil | 7 kun |
| 112 | 5,19·10³³ | 10¹⁷ yil | 10¹⁴ yil | 10⁸ yil |
| 128 | 3,40·10³⁸ | 10²² yil | 10¹⁹ yil | 10¹³ yil |
| 192 | 6,28·10⁵⁷ | 10⁴¹ yil | 10³⁸ yil | 10³² yil |
| 256 | 1,16·10⁷⁷ | 10⁶⁰ yil | 10⁵⁷ yil | 10⁵¹ yil |
