| Taxminiy kalit uzunligi | Masofalarni bo‘ladigan holatlar soni |
|:---:|:---:|
| 2 | 178 |
| 4 | 165 |
| 8 | 159 |
| 16 | 73 |
| 3 | 60 |
| 6 | 56 |
| 12 | 50 |
| 5 | 49 |
