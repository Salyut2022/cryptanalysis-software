| Matn turi | Moslik indeksi |
|:---:|:---:|
| O‘zbek tili (korpus) | 0,0715 |
| Ingliz tili (standart chastotalar) | 0,0655 |
| Tekis taqsimlangan tasodifiy matn | 0,0385 |
| Nazariy qiymat 1/26 | 0,0385 |
