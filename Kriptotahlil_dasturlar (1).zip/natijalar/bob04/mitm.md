| Ko‘rsatkich | Qiymat |
|:---:|:---:|
| Haqiqiy kalit juftligi (k₁, k₂) | (A59E, A056) |
| Jadval hajmi (xotira) | 2¹⁶ = 65 536 yozuv |
| Shifrlash/ochish amallari | 2·2¹⁶ ≈ 1,3·10⁵ (to‘liq tanlashda 2³² ≈ 4,3·10⁹) |
| 1-juftlik bo‘yicha nomzodlar | 65208 |
| 2-juftlik tekshiruvidan keyin | 6 |
| 3-juftlik tekshiruvidan keyin | 1: (A59E, A056) |
| Hujum vaqti (Python) | 2,3 s |
