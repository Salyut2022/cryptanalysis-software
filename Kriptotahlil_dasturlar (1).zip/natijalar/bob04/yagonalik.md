| Ma’lum (P, C) juftliklar soni | Mos keluvchi kalitlar soni | To‘g‘ri kalit ro‘yxatda |
|:---:|:---:|:---:|
| 1 | 4 | ha |
| 2 | 1 | ha |
| 3 | 1 | ha |
| 4 | 1 | ha |
