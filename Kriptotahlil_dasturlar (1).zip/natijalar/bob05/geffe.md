| Registr | Uzunligi | Tekshirilgan holatlar | Eng yuqori moslik | Holat to‘g‘ri tiklandimi |
|:---:|:---:|:---:|:---:|:---:|
| LFSR-2 | 11 | 2047 | 0,772 | ha |
| LFSR-3 | 13 | 8191 | 0,757 | ha |
| LFSR-1 | 7 | 127 | 1,000 (to‘liq mos) | ha |
