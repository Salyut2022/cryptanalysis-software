| Generator (n = 100 000 bit) | Monobit, P | Blokli chastota, P | Seriyalar, P | Xulosa (α = 0,01) |
|:---:|:---:|:---:|:---:|:---:|
| OS kriptografik generatori (secrets) | 0,644 | 0,548 | 0,095 | o‘tdi |
| RC4 kalit oqimi | 0,157 | 0,466 | 0,786 | o‘tdi |
| ChKG (m = 2³¹) ning kichik biti | 1,000 | 1,000 | 0,000 | o‘tmadi |
| LFSR, L = 17 | 0,540 | 0,957 | 0,490 | o‘tdi |
| Siljigan generator, P(1) = 0,51 | 0,000 | 0,080 | 0,000 | o‘tmadi |
