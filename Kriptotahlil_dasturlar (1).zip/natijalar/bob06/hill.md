| Ko‘rsatkich | Qiymat |
|:---:|:---:|
| Ma’lum ochiq matn | KRIPTOTAHLIL |
| Unga mos shifrmatn | LJVRXGFMYNBP |
| Foydalanilgan bigrammalar | KR→LJ, TO→XG |
| Tiklangan kalit matritsasi K | [[3, 5], [2, 7]] |
| Haqiqiy kalit | [[3, 5], [2, 7]] |
