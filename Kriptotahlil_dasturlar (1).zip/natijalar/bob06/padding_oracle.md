| Ko‘rsatkich | Qiymat |
|:---:|:---:|
| Shifrmatn bloklari soni (IV dan tashqari) | 3 |
| Orakulga so‘rovlar soni | 5995 |
| Bir baytga o‘rtacha so‘rov | 124,9 |
| Tiklangan ochiq matn | Karta raqami: 8600 1234 5678 9012 |
| Hujum vaqti | 0,04 s |
