| Qadam | Qiymat |
|:---:|:---:|
| Ochiq kalit (n, e) | (1000036000099, 65537) |
| Ushlangan shifrmatn c | 960249943711 |
| Hujumchi yuborgan c′ = c·rᵉ mod n (r = 7) | 267754735855 |
| Orakul javobi m′ = (c′)ᵈ mod n | 296969694 |
| m = m′·r⁻¹ mod n | 42424242 |
| Haqiqiy ochiq matn | 42424242 |
