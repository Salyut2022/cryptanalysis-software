| Algoritm | Realizatsiya | Tezlik, MB/s |
|:---:|:---:|:---:|
| AES-128-GCM | OpenSSL (cryptography kutubxonasi) | 7 334 |
| AES-256-GCM | OpenSSL (cryptography kutubxonasi) | 6 950 |
| ChaCha20-Poly1305 | OpenSSL (cryptography kutubxonasi) | 2 761 |
| AES-128 (ECB) | Ushbu qo‘llanmadagi sof Python realizatsiyasi | 0,1390 |
