| S-blok | O‘zgaruvchilar (x, y) | Darajasi ≤ 2 bo‘lgan monomlar | Matritsa rangi | Chiziqli erkli kvadratik tenglamalar |
|:---:|:---:|:---:|:---:|:---:|
| O‘quv SPN (4 bit) | 8 | 37 | 16 | 21 |
| PRESENT (4 bit) | 8 | 37 | 16 | 21 |
| AES (8 bit) | 16 | 137 | 98 | 39 |
