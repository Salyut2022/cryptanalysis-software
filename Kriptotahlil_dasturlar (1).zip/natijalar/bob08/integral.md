| To‘plam | Tanlangan matnlar | K5 1-nibl nomzodlari | 2-nibl | 3-nibl | 4-nibl |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 1 | 16 | 16 | 2 | 3 | 2 |
| 2 | 32 | 4 | 1 | 1 | 1 |
| 3 | 48 | 1 | 1 | 1 | 1 |
