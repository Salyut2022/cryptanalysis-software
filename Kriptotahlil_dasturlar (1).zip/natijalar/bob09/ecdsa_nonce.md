| Ko‘rsatkich | Qiymat (16-lik, boshi) |
|:---:|:---:|
| Ikkala imzodagi r (bir xil!) | 3e6880637c373fe7985cea4f… |
| k = (z₁ − z₂)/(s₁ − s₂) mod n | f97da2c870b8bfcb2c8fa16c… |
| d = (s₁k − z₁)/r mod n | 43c63be028b7c5e5ce57dfe5… |
| Tiklangan d haqiqiysiga tengmi | ha |
