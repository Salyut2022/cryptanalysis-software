| Hujum | Shart | Natija |
|:---:|:---:|:---:|
| Ferma usuli | 1024 bitli n, |p − q| < 2²⁰⁰ | 1 qadamda faktorlandi: ha |
| Pollard p − 1 | 475 bitli n, p − 1 silliq | p topildi: ha, 0,01 s |
| Viner hujumi | 1024 bitli n, d ≈ 2²⁵⁰ < n^{1/4}/3 | d tiklandi: ha, 0,3 ms |
| Hostad hujumi | e = 3, uch xil 1024 bitli modul | xabar: «Uchrashuv soat 14:00 da, 3-xonada» |
| Umumiy EKUB | 20 ta 512 bitli modul, bitta tub son takrorlangan | zaif juftlik(lar): [(3, 13)] |
