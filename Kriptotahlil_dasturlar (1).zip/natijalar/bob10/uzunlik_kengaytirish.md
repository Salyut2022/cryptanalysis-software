| Ko‘rsatkich | Qiymat |
|:---:|:---:|
| Asl xabar | foydalanuvchi=ali&rol=talaba |
| Asl MAC (boshi) | 6ff46632be433f6ed3cb5f450e2dc241… |
| Soxta xabar | asl xabar + to‘ldirish baytlari + «&rol=admin» |
| Soxta xabar uzunligi, bayt | 58 |
| Soxta MAC (boshi) | 7dad8d885e9661c473b1048280a7b8c4… |
| Server tekshiruvidan o‘tdimi | ha |
