| Raundlar soni | O‘qitish / test namunalari | Test aniqligi, % | Xulosa |
|:---:|:---:|:---:|:---:|
| 1 | 30 000 / 10 000 | 100,0 | farqlay oladi |
| 2 | 30 000 / 10 000 | 98,7 | farqlay oladi |
| 3 | 30 000 / 10 000 | 75,9 | farqlay oladi |
| 4 | 30 000 / 10 000 | 60,7 | farqlay oladi |
